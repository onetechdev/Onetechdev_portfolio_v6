<?php
require_once 'inc/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {

    $email    = clean($conn, $_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = "Cika dukkan filayen";
        redirect('index.php');
    }

    $res = $conn->query("SELECT * FROM users WHERE email='$email' LIMIT 1");

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            redirect('home.php');
        } else {
            $_SESSION['login_error'] = "❌ Password ba daidai ba ne";
            redirect('index.php');
        }
    } else {
        $_SESSION['login_error'] = "❌ Babu account tare da wannan email";
        redirect('index.php');
    }
}

redirect('index.php');
?>