<?php
session_start();
require_once 'inc/config.php';
header('Content-Type: application/json');

$data   = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

if ($action === 'get') {
    $email = $conn->real_escape_string(trim($data['email'] ?? ''));
    $user  = $conn->query("SELECT id,credential_id FROM users WHERE email='$email'")->fetch_assoc();

    if (!$user || empty($user['credential_id'])) {
        echo json_encode(['success'=>false,'message'=>'Baka register fingerprint ba tukuna. Danna "Register Yatsa" a sama']); exit;
    }

    // Random challenge
    $challenge = base64_encode(random_bytes(32));
    $_SESSION['webauthn_challenge'] = $challenge;
    $_SESSION['webauthn_email']     = $email;

    echo json_encode([
        'success'      => true,
        'challenge'    => $challenge,
        'credentialId' => $user['credential_id'],
    ]);
    exit;
}

if ($action === 'verify') {
    // Find user by credential_id
    $credId = $conn->real_escape_string($data['id'] ?? '');
    $user   = $conn->query("SELECT id,username,role FROM users WHERE credential_id='$credId'")->fetch_assoc();

    if ($user) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        // Update last seen
        $conn->query("UPDATE users SET last_seen=NOW() WHERE id=".$user['id']);
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'message'=>'Fingerprint bai daidaita ba. Sake gwadawa ko shiga da password']);
    }
    exit;
}

echo json_encode(['success'=>false,'message'=>'Action ba daidai ba']);
