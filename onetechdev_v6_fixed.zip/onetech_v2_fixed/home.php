<?php
require_once 'inc/config.php';
if (!isLoggedIn()) redirect('index.php');

$uid      = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Handle new post (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_post'])) {
    $content    = clean($conn, $_POST['content'] ?? '');
    $media_url  = '';
    $media_type = 'none';
    if (isset($_FILES['media']) && $_FILES['media']['error'] === 0) {
        $ext  = strtolower(pathinfo($_FILES['media']['name'], PATHINFO_EXTENSION));
        $img  = ['jpg','jpeg','png','gif','webp'];
        $vid  = ['mp4','webm','mov'];
        $fn   = uniqid().'.'.$ext;
        $dest = 'uploads/'.$fn;
        if (in_array($ext,$img))      { move_uploaded_file($_FILES['media']['tmp_name'],$dest); $media_url=$dest; $media_type='image'; }
        elseif (in_array($ext,$vid))  { move_uploaded_file($_FILES['media']['tmp_name'],$dest); $media_url=$dest; $media_type='video'; }
    }
    $conn->query("INSERT INTO posts (user_id,content,media_url,media_type,post_type) VALUES ($uid,'$content','$media_url','$media_type','post')");
    echo json_encode(['ok'=>true]); exit;
}

// Handle like (AJAX)
if ($_POST['action'] ?? '' === 'like') {
    $pid = (int)($_POST['post_id'] ?? 0);
    $chk = $conn->query("SELECT id FROM post_likes WHERE post_id=$pid AND user_id=$uid");
    if ($chk->num_rows === 0) {
        $conn->query("INSERT INTO post_likes (post_id,user_id) VALUES ($pid,$uid)");
        $conn->query("UPDATE posts SET likes_count=likes_count+1 WHERE id=$pid");
        // Track interaction
        $conn->query("INSERT INTO post_interactions (user_id,post_id,post_owner_id,action)
            SELECT $uid,$pid,user_id,'like' FROM posts WHERE id=$pid
            ON DUPLICATE KEY UPDATE created_at=NOW()");
        $row = $conn->query("SELECT user_id,likes_count FROM posts WHERE id=$pid")->fetch_assoc();
        if ($row['user_id'] != $uid)
            $conn->query("INSERT INTO notifications (user_id,from_user_id,type,ref_id,message) VALUES ({$row['user_id']},$uid,'like',$pid,'Ya like post ɗinka')");
        echo json_encode(['liked'=>true,'count'=>$row['likes_count']]); exit;
    } else {
        $conn->query("DELETE FROM post_likes WHERE post_id=$pid AND user_id=$uid");
        $conn->query("UPDATE posts SET likes_count=likes_count-1 WHERE id=$pid");
        $row = $conn->query("SELECT likes_count FROM posts WHERE id=$pid")->fetch_assoc();
        echo json_encode(['liked'=>false,'count'=>$row['likes_count']]); exit;
    }
}

// Handle follow (AJAX)
if ($_POST['action'] ?? '' === 'follow') {
    $fid = (int)($_POST['follow_id'] ?? 0);
    if ($fid && $fid !== $uid) {
        $chk = $conn->query("SELECT id FROM follows WHERE follower_id=$uid AND following_id=$fid");
        if ($chk->num_rows === 0) {
            $conn->query("INSERT INTO follows (follower_id,following_id) VALUES ($uid,$fid)");
            $conn->query("UPDATE users SET following_count=following_count+1 WHERE id=$uid");
            $conn->query("UPDATE users SET followers_count=followers_count+1 WHERE id=$fid");
            $conn->query("INSERT INTO notifications (user_id,from_user_id,type,message) VALUES ($fid,$uid,'follow','Ya biyo ka')");
            echo json_encode(['followed'=>true]); exit;
        } else {
            $conn->query("DELETE FROM follows WHERE follower_id=$uid AND following_id=$fid");
            $conn->query("UPDATE users SET following_count=following_count-1 WHERE id=$uid");
            $conn->query("UPDATE users SET followers_count=followers_count-1 WHERE id=$fid");
            echo json_encode(['followed'=>false]); exit;
        }
    }
    exit;
}

// Handle save post (AJAX)
if ($_POST['action'] ?? '' === 'save') {
    $pid = (int)($_POST['post_id'] ?? 0);
    $chk = $conn->query("SELECT id FROM post_saves WHERE post_id=$pid AND user_id=$uid");
    if ($chk->num_rows === 0) {
        $conn->query("INSERT INTO post_saves (user_id,post_id) VALUES ($uid,$pid)");
        echo json_encode(['saved'=>true]); exit;
    } else {
        $conn->query("DELETE FROM post_saves WHERE user_id=$uid AND post_id=$pid");
        echo json_encode(['saved'=>false]); exit;
    }
}

// Track video view (AJAX)
if ($_POST['action'] ?? '' === 'track') {
    $pid = (int)($_POST['post_id'] ?? 0);
    if ($pid) {
        $conn->query("UPDATE posts SET view_count=view_count+1 WHERE id=$pid");
        $conn->query("INSERT INTO post_interactions (user_id,post_id,post_owner_id,action)
            SELECT $uid,$pid,user_id,'view' FROM posts WHERE id=$pid
            ON DUPLICATE KEY UPDATE created_at=NOW()");
    }
    exit;
}

// My profile info
$me          = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
$notif_count = $conn->query("SELECT COUNT(*) c FROM notifications WHERE user_id=$uid AND is_read=0")->fetch_assoc()['c'];
$msg_count   = $conn->query("SELECT COUNT(*) c FROM messages WHERE receiver_id=$uid AND is_read=0")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Feed – Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');
:root{--accent:#00d4ff;--bg:#0a0a0a;--card:#111;--border:#1e1e1e;--sub:#888;}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{background:var(--bg);color:#eee;min-height:100vh;padding-bottom:70px;}

/* NAV */
.topnav{position:sticky;top:0;background:#111;border-bottom:1px solid var(--border);
    display:flex;justify-content:space-between;align-items:center;padding:10px 16px;z-index:1000;}
.topnav .logo{color:var(--accent);font-weight:800;font-size:1.2rem;text-decoration:none;}
.topnav .nav-icons{display:flex;gap:18px;align-items:center;}
.topnav .nav-icons a{color:#ccc;font-size:1.1rem;position:relative;text-decoration:none;}
.topnav .nav-icons a:hover{color:var(--accent);}
.badge{position:absolute;top:-6px;right:-8px;background:#f55;color:#fff;font-size:.6rem;
    width:15px;height:15px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;}

/* LAYOUT */
.feed-layout{display:grid;grid-template-columns:230px 1fr 230px;gap:18px;max-width:1060px;margin:16px auto;padding:0 12px;}
@media(max-width:900px){.feed-layout{grid-template-columns:1fr;padding:0 6px;}.sidebar-left,.sidebar-right{display:none;}}

/* SIDEBAR */
.sidebar{position:sticky;top:68px;height:fit-content;}
.profile-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:18px;text-align:center;}
.profile-card img{width:68px;height:68px;border-radius:50%;object-fit:cover;border:3px solid var(--accent);margin-bottom:8px;}
.profile-card h3{font-size:.95rem;}
.profile-card .role{font-size:.7rem;color:var(--accent);background:rgba(0,212,255,.1);
    padding:2px 8px;border-radius:10px;display:inline-block;margin:4px 0;}
.sidebar-link{display:flex;align-items:center;gap:10px;padding:10px 12px;color:#aaa;
    text-decoration:none;border-radius:10px;font-size:.85rem;transition:.2s;}
.sidebar-link:hover,.sidebar-link.active{background:rgba(0,212,255,.08);color:var(--accent);}
.sidebar-link i{width:18px;text-align:center;}

/* STORIES ROW */
.stories-wrap{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:14px;}
.stories-wrap h4{font-size:.75rem;color:var(--sub);margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px;}
.stories-row{display:flex;gap:10px;overflow-x:auto;padding-bottom:4px;scrollbar-width:none;}
.stories-row::-webkit-scrollbar{display:none;}
.story-bubble{display:flex;flex-direction:column;align-items:center;gap:4px;cursor:pointer;min-width:62px;}
.story-bubble .ring{width:58px;height:58px;border-radius:50%;padding:2.5px;
    background:linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);flex-shrink:0;}
.story-bubble .ring.seen{background:#333;}
.story-bubble .ring img{width:100%;height:100%;border-radius:50%;object-fit:cover;border:2.5px solid var(--bg);}
.story-bubble .ring.add-story{background:var(--accent);display:flex;align-items:center;justify-content:center;
    font-size:1.4rem;color:#000;}
.story-bubble span{font-size:.6rem;color:#aaa;text-align:center;max-width:60px;
    overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}

/* COMPOSER */
.composer{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:14px;}
.composer-top{display:flex;gap:10px;align-items:flex-start;}
.composer-top img{width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--accent);}
.composer-top textarea{flex:1;background:#1a1a1a;border:1px solid var(--border);border-radius:12px;
    padding:10px 14px;color:#eee;resize:none;font-size:.9rem;outline:none;min-height:48px;
    font-family:'Poppins',sans-serif;line-height:1.4;}
.composer-top textarea:focus{border-color:var(--accent);}
.composer-actions{display:flex;align-items:center;justify-content:space-between;margin-top:10px;flex-wrap:wrap;gap:8px;}
.compose-btns{display:flex;gap:6px;}
.compose-btn{background:rgba(0,212,255,.08);border:1px solid rgba(0,212,255,.2);color:var(--accent);
    border-radius:20px;padding:6px 14px;font-size:.78rem;cursor:pointer;display:flex;align-items:center;gap:6px;}
.compose-btn:hover{background:rgba(0,212,255,.15);}
.compose-btn input{display:none;}
.post-btn{background:linear-gradient(135deg,var(--accent),#0099cc);color:#000;border:none;
    border-radius:20px;padding:8px 22px;font-weight:700;font-size:.85rem;cursor:pointer;}
.media-preview{margin-top:10px;position:relative;}
.media-preview img,.media-preview video{max-width:100%;border-radius:10px;max-height:220px;object-fit:contain;}
.media-preview .remove-media{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.7);
    color:#fff;border:none;border-radius:50%;width:26px;height:26px;cursor:pointer;font-size:.8rem;}

/* POST CARD */
.post-card{background:var(--card);border:1px solid var(--border);border-radius:14px;
    margin-bottom:12px;overflow:hidden;position:relative;}
.post-header{display:flex;align-items:center;gap:10px;padding:12px 14px 8px;}
.post-header img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--accent);cursor:pointer;}
.post-name{font-weight:700;font-size:.9rem;cursor:pointer;}
.post-name:hover{color:var(--accent);}
.post-time{font-size:.7rem;color:var(--sub);margin-top:1px;}
.post-role{font-size:.65rem;color:var(--accent);background:rgba(0,212,255,.1);padding:1px 7px;border-radius:8px;margin-left:4px;}
.post-options{margin-left:auto;background:none;border:none;color:#666;cursor:pointer;padding:4px 8px;font-size:1rem;}
.post-options:hover{color:#fff;}
.post-menu{display:none;position:absolute;right:12px;top:46px;background:#1a1a1a;
    border:1px solid #333;border-radius:12px;padding:6px 0;z-index:10;min-width:160px;box-shadow:0 4px 20px rgba(0,0,0,.6);}
.post-menu.open{display:block;}
.pmenu-item{padding:10px 16px;font-size:.82rem;cursor:pointer;display:flex;align-items:center;gap:10px;color:#ccc;}
.pmenu-item:hover{background:#222;color:#fff;}
.post-text{padding:4px 14px 10px;font-size:.88rem;line-height:1.5;white-space:pre-wrap;word-break:break-word;}
.post-media{width:100%;max-height:480px;object-fit:cover;cursor:pointer;display:block;}
.post-video-wrap{position:relative;}
.post-video-wrap video{width:100%;max-height:480px;object-fit:cover;cursor:pointer;display:block;}
.vid-play-overlay{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
    font-size:3rem;color:rgba(255,255,255,.7);pointer-events:none;transition:.2s;}
.post-stats{display:flex;justify-content:space-between;padding:6px 14px;font-size:.75rem;color:var(--sub);border-top:1px solid var(--border);}
.post-actions{display:flex;border-top:1px solid var(--border);}
.post-action-btn{flex:1;background:none;border:none;color:#aaa;padding:10px 0;cursor:pointer;
    font-size:.8rem;display:flex;align-items:center;justify-content:center;gap:5px;transition:.2s;}
.post-action-btn:hover{color:var(--accent);background:rgba(0,212,255,.04);}
.post-action-btn.liked{color:#e74c3c;}
.post-action-btn.liked i{color:#e74c3c;}
.post-action-btn.saved{color:var(--accent);}
.context-label{font-size:.65rem;margin-top:1px;}

/* COMMENTS */
.comments-box{display:none;padding:10px 14px;background:#0f0f0f;border-top:1px solid var(--border);}
.comments-box.open{display:block;}
.comment-input-row{display:flex;gap:8px;align-items:center;margin-bottom:10px;}
.comment-input-row img{width:30px;height:30px;border-radius:50%;object-fit:cover;}
.comment-input-row input{flex:1;background:#1a1a1a;border:1px solid var(--border);border-radius:20px;
    padding:8px 14px;color:#eee;font-size:.82rem;outline:none;}
.comment-input-row input:focus{border-color:var(--accent);}
.comment-input-row button{background:var(--accent);color:#000;border:none;border-radius:50%;
    width:32px;height:32px;cursor:pointer;font-size:.8rem;}
.comment-item{display:flex;gap:8px;margin-bottom:8px;}
.comment-item img{width:28px;height:28px;border-radius:50%;object-fit:cover;flex-shrink:0;}
.comment-bubble{background:#1a1a1a;border-radius:12px;padding:8px 12px;flex:1;}
.comment-bubble strong{font-size:.78rem;color:var(--accent);cursor:pointer;}
.comment-bubble p{font-size:.82rem;margin-top:2px;}
.comment-bubble small{font-size:.65rem;color:var(--sub);display:block;margin-top:3px;}

/* SUGGEST USERS */
.suggest-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:12px;}
.suggest-card h4{font-size:.75rem;color:var(--sub);margin-bottom:10px;text-transform:uppercase;}
.suggest-item{display:flex;align-items:center;gap:10px;padding:6px 0;}
.suggest-item img{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--border);cursor:pointer;}
.suggest-item .si-name{font-size:.83rem;font-weight:600;cursor:pointer;}
.suggest-item .si-name:hover{color:var(--accent);}
.suggest-item .si-role{font-size:.68rem;color:var(--sub);}
.follow-btn{margin-left:auto;background:rgba(0,212,255,.1);border:1px solid rgba(0,212,255,.3);
    color:var(--accent);border-radius:20px;padding:5px 14px;font-size:.75rem;cursor:pointer;white-space:nowrap;}
.follow-btn:hover{background:var(--accent);color:#000;}
.follow-btn.following{background:#333;border-color:#444;color:#888;}

/* STORY VIEWER — WhatsApp style */
.story-viewer{display:none;position:fixed;inset:0;background:#000;z-index:99999;
    flex-direction:column;align-items:center;justify-content:center;}
.story-viewer.open{display:flex;}
.sv-progress{position:absolute;top:0;left:0;right:0;display:flex;gap:3px;padding:10px 12px;z-index:2;}
.sv-bar{flex:1;height:3px;background:rgba(255,255,255,.3);border-radius:2px;overflow:hidden;}
.sv-bar-fill{height:100%;background:#fff;width:0%;transition:width linear;}
.sv-header{position:absolute;top:22px;left:12px;right:12px;display:flex;align-items:center;gap:10px;z-index:2;}
.sv-header img{width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid #fff;}
.sv-header .sv-name{font-size:.9rem;font-weight:700;color:#fff;text-shadow:0 1px 4px #000;}
.sv-header .sv-time{font-size:.7rem;color:rgba(255,255,255,.7);}
.sv-close{margin-left:auto;color:#fff;font-size:1.4rem;background:none;border:none;cursor:pointer;}
.sv-media{max-width:100%;max-height:100%;object-fit:contain;}
.sv-tap-left{position:absolute;left:0;top:0;width:33%;height:100%;z-index:1;cursor:pointer;}
.sv-tap-right{position:absolute;right:0;top:0;width:33%;height:100%;z-index:1;cursor:pointer;}
.sv-reply{position:absolute;bottom:20px;left:16px;right:16px;display:flex;gap:8px;align-items:center;}
.sv-reply input{flex:1;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.3);
    border-radius:25px;padding:10px 16px;color:#fff;font-size:.85rem;outline:none;}
.sv-reply input::placeholder{color:rgba(255,255,255,.6);}
.sv-reply input:focus{border-color:#fff;}
.sv-reply button{background:#fff;color:#000;border:none;border-radius:50%;width:40px;height:40px;cursor:pointer;}

/* MEDIA LIGHTBOX */
.lightbox{display:none;position:fixed;inset:0;background:rgba(0,0,0,.95);z-index:99998;
    align-items:center;justify-content:center;}
.lightbox.open{display:flex;}
.lightbox img,.lightbox video{max-width:96%;max-height:96%;object-fit:contain;border-radius:8px;}
.lightbox-close{position:absolute;top:16px;right:20px;color:#fff;font-size:1.8rem;cursor:pointer;background:none;border:none;}

/* NOTIFICATIONS PANEL */
.notif-panel{display:none;position:fixed;top:58px;right:16px;width:300px;background:#111;
    border:1px solid #222;border-radius:14px;z-index:5000;max-height:420px;overflow-y:auto;box-shadow:0 8px 30px rgba(0,0,0,.6);}
.notif-panel.open{display:block;}
.notif-panel h4{padding:12px 16px;border-bottom:1px solid #222;color:var(--accent);font-size:.85rem;}
.notif-item{padding:10px 16px;border-bottom:1px solid #1a1a1a;font-size:.8rem;cursor:pointer;}
.notif-item:hover{background:#1a1a1a;}
.notif-item.unread{background:rgba(0,212,255,.04);}
.notif-item small{display:block;color:var(--sub);font-size:.7rem;margin-top:2px;}

/* MOBILE BOTTOM NAV */
.mobile-bottom-nav{display:none;position:fixed;bottom:0;left:0;width:100%;background:#111;
    border-top:1px solid var(--border);z-index:9999;padding:6px 0 calc(6px + env(safe-area-inset-bottom));}
.mobile-bottom-nav .nav-items{display:flex;justify-content:space-around;align-items:center;}
.mobile-bottom-nav a{display:flex;flex-direction:column;align-items:center;gap:2px;
    color:#666;text-decoration:none;font-size:.6rem;padding:4px 8px;position:relative;}
.mobile-bottom-nav a.active,.mobile-bottom-nav a:hover{color:var(--accent);}
.mobile-bottom-nav a i{font-size:1.25rem;}
.mobile-bottom-nav a img{width:26px;height:26px;border-radius:50%;object-fit:cover;border:2px solid #333;}
.mobile-bottom-nav a.active img{border-color:var(--accent);}
.mobile-bottom-nav .mbadge{position:absolute;top:1px;right:4px;background:#f55;color:#fff;
    font-size:.5rem;width:13px;height:13px;border-radius:50%;display:flex;align-items:center;justify-content:center;}
@media(max-width:900px){
    .mobile-bottom-nav{display:block;}
    .topnav .nav-icons{display:none;}
    body{padding-bottom:72px;}
}

/* LOADING SPINNER */
.feed-spinner{text-align:center;padding:30px;color:var(--sub);}
.feed-spinner i{font-size:1.5rem;animation:spin .8s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}

/* PROFILE QUICK VIEW */
.profile-popup{display:none;position:fixed;inset:0;z-index:88888;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.6);}
.profile-popup.open{display:flex;}
.pp-card{background:#111;border-radius:20px 20px 0 0;padding:20px;width:100%;max-width:500px;border:1px solid var(--border);}
.pp-cover{height:80px;background:linear-gradient(135deg,#0f0c29,#302b63,rgba(0,212,255,.3));border-radius:12px;margin-bottom:-30px;position:relative;}
.pp-avatar{width:68px;height:68px;border-radius:50%;border:3px solid var(--accent);object-fit:cover;margin:0 auto;display:block;position:relative;z-index:1;}
.pp-name{text-align:center;margin-top:8px;font-weight:800;font-size:1rem;}
.pp-role{text-align:center;font-size:.7rem;color:var(--accent);}
.pp-bio{text-align:center;font-size:.8rem;color:#aaa;margin:8px 16px;line-height:1.4;}
.pp-stats{display:flex;justify-content:center;gap:30px;margin:12px 0;padding:10px;background:#1a1a1a;border-radius:12px;}
.pp-stat{text-align:center;}
.pp-stat .n{font-size:1.1rem;font-weight:800;color:var(--accent);}
.pp-stat .l{font-size:.65rem;color:var(--sub);}
.pp-actions{display:flex;gap:8px;margin-top:12px;}
.pp-btn{flex:1;padding:10px;border-radius:20px;border:none;cursor:pointer;font-weight:700;font-size:.82rem;}
.pp-btn-follow{background:var(--accent);color:#000;}
.pp-btn-msg{background:#222;color:#eee;border:1px solid var(--border);}
.pp-btn-profile{background:#1a1a1a;color:var(--accent);border:1px solid rgba(0,212,255,.3);}

</style>
</head>
<body>

<!-- TOP NAV -->
<nav class="topnav">
    <a href="home.php" class="logo"><i class="fa fa-code"></i> Onetech Dev</a>
    <div class="nav-icons">
        <a href="home.php" title="Feed"><i class="fa fa-home"></i></a>
        <a href="videos.php" title="Videos"><i class="fa fa-play-circle"></i></a>
        <a href="sakon.php" title="Sako" style="position:relative;">
            <i class="fa fa-comment"></i>
            <?php if($msg_count>0):?><span class="badge"><?=$msg_count?></span><?php endif;?>
        </a>
        <a href="#" title="Sanarwa" onclick="toggleNotif(event)" style="position:relative;">
            <i class="fa fa-bell"></i>
            <?php if($notif_count>0):?><span class="badge" id="notif-badge"><?=$notif_count?></span><?php endif;?>
        </a>
        <a href="profile.php?id=<?=$uid?>" title="Profile">
            <img src="<?=$me['profile_pic']?:''?>" onerror="this.src='assets/default.png'"
                 style="width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid var(--accent);">
        </a>
        <a href="logout.php" title="Fita"><i class="fa fa-sign-out-alt" style="color:#f55;"></i></a>
    </div>
</nav>

<!-- NOTIFICATIONS PANEL -->
<div class="notif-panel" id="notif-panel">
    <h4><i class="fa fa-bell"></i> Sanarwa</h4>
    <?php
    $notifs = $conn->query("SELECT n.*,u.username,u.profile_pic FROM notifications n
        LEFT JOIN users u ON n.from_user_id=u.id
        WHERE n.user_id=$uid ORDER BY n.created_at DESC LIMIT 25");
    if(!$notifs||$notifs->num_rows===0):?>
        <div class="notif-item">Babu sanarwa</div>
    <?php else: while($n=$notifs->fetch_assoc()):
        $cls=$n['is_read']==0?'unread':'';
    ?>
        <div class="notif-item <?=$cls?>">
            <strong><?=$n['username']??'System'?></strong> <?=$n['message']?>
            <small><?=date('d M H:i',strtotime($n['created_at']))?></small>
        </div>
    <?php endwhile; endif;
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_id=$uid");?>
</div>

<!-- FEED LAYOUT -->
<div class="feed-layout">

<!-- SIDEBAR LEFT -->
<div class="sidebar sidebar-left">
    <div class="profile-card">
        <img src="<?=$me['profile_pic']?:''?>" onerror="this.src='assets/default.png'" onclick="location.href='profile.php?id=<?=$uid?>'">
        <h3><?=$me['username']?></h3>
        <div class="role"><?=str_replace('_',' ',ucfirst($me['role']))?></div>
        <?php if($me['bio']): ?><p style="font-size:.72rem;color:#888;margin-top:6px;"><?=htmlspecialchars(mb_substr($me['bio'],0,80))?></p><?php endif;?>
    </div>
    <div style="margin-top:10px;">
        <a href="home.php" class="sidebar-link active"><i class="fa fa-home"></i> Feed</a>
        <a href="profile.php?id=<?=$uid?>" class="sidebar-link"><i class="fa fa-user"></i> Profile Na</a>
        <a href="videos.php" class="sidebar-link"><i class="fa fa-play-circle"></i> Videos</a>
        <a href="sakon.php" class="sidebar-link"><i class="fa fa-comment"></i> Saƙo</a>
        <a href="logout.php" class="sidebar-link" style="color:#f55;"><i class="fa fa-sign-out-alt"></i> Fita</a>
    </div>
</div>

<!-- CENTER FEED -->
<div class="feed-center">

    <!-- STORIES -->
    <div class="stories-wrap">
        <h4><i class="fa fa-circle-notch"></i> Stories</h4>
        <div class="stories-row" id="stories-row">
            <!-- Add Story -->
            <div class="story-bubble" onclick="addStory()">
                <div class="ring add-story"><i class="fa fa-plus"></i></div>
                <span>Ƙara</span>
                <input type="file" id="story-file" accept="image/*,video/*" style="display:none" onchange="uploadStory(this)">
            </div>
        </div>
    </div>

    <!-- COMPOSER -->
    <div class="composer">
        <div class="composer-top">
            <img src="<?=$me['profile_pic']?:''?>" onerror="this.src='assets/default.png'">
            <textarea id="post-text" placeholder="Menene ke faruwa a tunaninka?" rows="2"
                      oninput="autoResize(this)"></textarea>
        </div>
        <div id="media-preview" class="media-preview" style="display:none;"></div>
        <div class="composer-actions">
            <div class="compose-btns">
                <label class="compose-btn"><i class="fa fa-image"></i> Hoto
                    <input type="file" accept="image/*" onchange="previewMedia(this,'image')">
                </label>
                <label class="compose-btn"><i class="fa fa-video"></i> Video
                    <input type="file" accept="video/*" onchange="previewMedia(this,'video')">
                </label>
            </div>
            <button class="post-btn" onclick="submitPost()"><i class="fa fa-paper-plane"></i> Post</button>
        </div>
    </div>

    <!-- FEED POSTS (loaded by JS) -->
    <div id="feed-container"></div>
    <div class="feed-spinner" id="feed-spinner"><i class="fa fa-circle-notch"></i></div>

</div>

<!-- SIDEBAR RIGHT -->
<div class="sidebar sidebar-right">
    <div class="suggest-card">
        <h4><i class="fa fa-user-plus"></i> Mutane Za Ka Iya Bi</h4>
        <?php
        $suggest = $conn->query("SELECT u.id,u.username,u.profile_pic,u.role,u.followers_count
            FROM users u WHERE u.id!=$uid AND u.id NOT IN (SELECT following_id FROM follows WHERE follower_id=$uid)
            ORDER BY u.followers_count DESC LIMIT 8");
        while($s=$suggest->fetch_assoc()):?>
        <div class="suggest-item">
            <img src="<?=$s['profile_pic']?:''?>" onerror="this.src='assets/default.png'"
                 onclick="showProfilePopup(<?=$s['id']?>)">
            <div>
                <div class="si-name" onclick="showProfilePopup(<?=$s['id']?>)"><?=htmlspecialchars($s['username'])?></div>
                <div class="si-role"><?=str_replace('_',' ',ucfirst($s['role']))?></div>
            </div>
            <button class="follow-btn" id="sb-follow-<?=$s['id']?>" onclick="followUser(<?=$s['id']?>,this)">
                <i class="fa fa-user-plus"></i> Bi
            </button>
        </div>
        <?php endwhile;?>
    </div>
</div>

</div><!-- /feed-layout -->

<!-- STORY VIEWER — WhatsApp Style -->
<div class="story-viewer" id="story-viewer">
    <div class="sv-progress" id="sv-progress"></div>
    <div class="sv-header">
        <img id="sv-avatar" src="">
        <div>
            <div class="sv-name" id="sv-name"></div>
            <div class="sv-time" id="sv-time"></div>
        </div>
        <button class="sv-close" onclick="closeStory()"><i class="fa fa-times"></i></button>
    </div>
    <div class="sv-tap-left" onclick="prevStory()"></div>
    <div class="sv-tap-right" onclick="nextStory()"></div>
    <div id="sv-media-wrap"></div>
    <div class="sv-reply">
        <input type="text" id="sv-reply-input" placeholder="Mayar da martani...">
        <button onclick="sendStoryReply()"><i class="fa fa-paper-plane"></i></button>
    </div>
</div>

<!-- MEDIA LIGHTBOX -->
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
    <button class="lightbox-close"><i class="fa fa-times"></i></button>
    <div id="lightbox-content"></div>
</div>

<!-- PROFILE POPUP -->
<div class="profile-popup" id="profile-popup" onclick="closeProfilePopup(event)">
    <div class="pp-card" id="pp-card">
        <div class="pp-cover" id="pp-cover"></div>
        <img class="pp-avatar" id="pp-avatar" src="" onerror="this.src='assets/default.png'">
        <div class="pp-name" id="pp-name"></div>
        <div class="pp-role" id="pp-role"></div>
        <div class="pp-bio" id="pp-bio"></div>
        <div class="pp-stats" id="pp-stats"></div>
        <div class="pp-actions" id="pp-actions"></div>
    </div>
</div>

<!-- MOBILE BOTTOM NAV -->
<nav class="mobile-bottom-nav">
    <div class="nav-items">
        <a href="home.php" class="active"><i class="fa fa-home"></i><span>Gida</span></a>
        <a href="videos.php"><i class="fa fa-play-circle"></i><span>Videos</span></a>
        <a href="sakon.php" style="position:relative;">
            <i class="fa fa-comment"></i>
            <?php if($msg_count>0):?><span class="mbadge"><?=$msg_count?></span><?php endif;?>
            <span>Sako</span>
        </a>
        <a href="#" onclick="toggleNotif(event)" style="position:relative;">
            <i class="fa fa-bell"></i>
            <?php if($notif_count>0):?><span class="mbadge" id="notif-badge-m"><?=$notif_count?></span><?php endif;?>
            <span>Sanarwa</span>
        </a>
        <a href="profile.php?id=<?=$uid?>">
            <img src="<?=$me['profile_pic']?:''?>" onerror="this.src='assets/default.png'">
            <span>Ni</span>
        </a>
    </div>
</nav>

<script>
const MY_ID   = <?=$uid?>;
const MY_PIC  = '<?=$me['profile_pic']?:''?>';
const MY_USER = '<?=addslashes($me['username'])?>';

// ─────────────────────────────────────────────
// FEED LOADING — Facebook Algorithm (load_posts.php)
// ─────────────────────────────────────────────
let feedPage  = 1;
let feedBusy  = false;
let feedDone  = false;

async function loadFeed() {
    if (feedBusy || feedDone) return;
    feedBusy = true;
    document.getElementById('feed-spinner').style.display = 'block';
    try {
        const r = await fetch(`load_posts.php?page=${feedPage}`);
        const html = await r.text();
        if (!html.trim() || html.includes('feed-empty')) { feedDone = true; }
        else {
            document.getElementById('feed-container').insertAdjacentHTML('beforeend', html);
            feedPage++;
            initVideoObserver();
        }
    } catch(e) {}
    feedBusy = false;
    document.getElementById('feed-spinner').style.display = feedDone ? 'none' : 'block';
    if (!feedDone) document.getElementById('feed-spinner').style.display = 'none';
}

// Infinite scroll
window.addEventListener('scroll', () => {
    if ((window.innerHeight + scrollY) >= document.body.offsetHeight - 500) loadFeed();
});
loadFeed();

// ─────────────────────────────────────────────
// STORY LOADING
// ─────────────────────────────────────────────
let currentStories = [];
let currentStoryIdx = 0;
let storyTimer = null;
let storyDuration = 5000; // 5 seconds per story

async function loadStories() {
    const row = document.getElementById('stories-row');
    const r   = await fetch('load_stories.php');
    const data = await r.json();
    currentStories = data;
    data.forEach((s, i) => {
        const b = document.createElement('div');
        b.className = 'story-bubble';
        b.innerHTML = `<div class="ring ${s.seen?'seen':''}">
            <img src="${s.profile_pic||'assets/default.png'}" onerror="this.src='assets/default.png'">
        </div><span>${s.firstname}</span>`;
        b.onclick = () => openStory(i);
        row.appendChild(b);
    });
}
loadStories();

function addStory() {
    document.getElementById('story-file').click();
}
async function uploadStory(input) {
    const file = input.files[0]; if (!file) return;
    const fd = new FormData();
    fd.append('story_media', file);
    await fetch('create_story.php', {method:'POST', body:fd});
    loadStories();
    input.value = '';
}

// WhatsApp-style story viewer
function openStory(idx) {
    currentStoryIdx = idx;
    document.getElementById('story-viewer').classList.add('open');
    renderStory();
}
function renderStory() {
    const s = currentStories[currentStoryIdx];
    if (!s) { closeStory(); return; }
    document.getElementById('sv-avatar').src = s.profile_pic || 'assets/default.png';
    document.getElementById('sv-name').textContent  = s.firstname + ' ' + s.lastname;
    document.getElementById('sv-time').textContent  = s.time_ago;
    // Progress bars
    const prog = document.getElementById('sv-progress');
    prog.innerHTML = currentStories.map((_,i) =>
        `<div class="sv-bar"><div class="sv-bar-fill" id="svbar-${i}" ${i<currentStoryIdx?'style="width:100%"':''}></div></div>`
    ).join('');
    // Media
    const wrap = document.getElementById('sv-media-wrap');
    wrap.innerHTML = '';
    if (s.type === 'image') {
        const img = document.createElement('img');
        img.src = s.src; img.className = 'sv-media';
        img.style.cssText = 'max-width:100%;max-height:100vh;object-fit:contain;';
        wrap.appendChild(img);
    } else {
        const vid = document.createElement('video');
        vid.src = s.src; vid.autoplay = true; vid.playsInline = true;
        vid.style.cssText = 'max-width:100%;max-height:100vh;object-fit:contain;';
        storyDuration = 15000;
        wrap.appendChild(vid);
    }
    // Animate progress bar
    clearTimeout(storyTimer);
    const bar = document.getElementById(`svbar-${currentStoryIdx}`);
    if (bar) {
        bar.style.transition = `width ${storyDuration/1000}s linear`;
        setTimeout(() => { bar.style.width = '100%'; }, 50);
    }
    storyTimer = setTimeout(() => nextStory(), storyDuration);
    storyDuration = 5000; // reset for next
    // Mark as seen via fetch
    fetch('create_story.php?seen=' + s.id);
}
function nextStory() {
    if (currentStoryIdx < currentStories.length - 1) { currentStoryIdx++; renderStory(); }
    else closeStory();
}
function prevStory() {
    if (currentStoryIdx > 0) { currentStoryIdx--; renderStory(); }
}
function closeStory() {
    clearTimeout(storyTimer);
    document.getElementById('story-viewer').classList.remove('open');
}
function sendStoryReply() {
    const inp = document.getElementById('sv-reply-input');
    const msg = inp.value.trim();
    if (!msg) return;
    const s = currentStories[currentStoryIdx];
    if (s) fetch('sakon.php?ajax=send', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({to: s.user_id, msg:'📖 Story: ' + msg})});
    inp.value = '';
    showToast('Amsa an aika!');
}

// ─────────────────────────────────────────────
// POST ACTIONS
// ─────────────────────────────────────────────
async function likePost(pid) {
    const btn = document.getElementById('like-btn-' + pid);
    const r   = await fetch('home.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=like&post_id=${pid}`});
    const d = await r.json();
    const icon = btn.querySelector('i');
    if (d.liked) { btn.classList.add('liked'); icon.className = 'fa fa-heart'; }
    else         { btn.classList.remove('liked'); icon.className = 'far fa-heart'; }
    const cnt = document.getElementById('like-count-' + pid);
    if (cnt) cnt.textContent = d.count > 0 ? '❤️ ' + d.count : '';
}

async function followUser(fid, btn) {
    const r = await fetch('home.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=follow&follow_id=${fid}`});
    const d = await r.json();
    if (btn) {
        if (d.followed) { btn.innerHTML='<i class="fa fa-check"></i> Biyo'; btn.classList.add('following'); }
        else            { btn.innerHTML='<i class="fa fa-user-plus"></i> Bi'; btn.classList.remove('following'); }
    }
    // Refresh sidebar follow btns
    const sb = document.getElementById('sb-follow-' + fid);
    if (sb) {
        if (d.followed) { sb.innerHTML='<i class="fa fa-check"></i> Biyo'; sb.classList.add('following'); }
        else            { sb.innerHTML='<i class="fa fa-user-plus"></i> Bi'; sb.classList.remove('following'); }
    }
}

async function savePost(pid, btn) {
    const r = await fetch('home.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=save&post_id=${pid}`});
    const d = await r.json();
    if (btn) btn.classList.toggle('saved', d.saved);
}

function toggleComments(pid) {
    const box = document.getElementById('cbox-' + pid);
    if (!box) return;
    box.classList.toggle('open');
    if (box.classList.contains('open') && !box.dataset.loaded) {
        loadComments(pid);
        box.dataset.loaded = '1';
    }
}

async function loadComments(pid) {
    const list = document.getElementById('clist-' + pid);
    const r = await fetch(`comment.php?load=1&post_id=${pid}`);
    list.innerHTML = await r.text();
}

async function sendComment(pid) {
    const inp = document.getElementById('cinput-' + pid);
    const msg = inp.value.trim();
    if (!msg) return;
    await fetch('comment.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`post_id=${pid}&content=${encodeURIComponent(msg)}`});
    inp.value = '';
    loadComments(pid);
    // Update comment count
    const cnt = document.getElementById('comment-count-' + pid);
    if (cnt) cnt.textContent = (parseInt(cnt.textContent)||0) + 1 + ' comments';
}

function sharePost(pid) {
    const url = window.location.origin + '/home.php?post=' + pid;
    if (navigator.share) {
        navigator.share({title:'Onetech Dev Post', url});
    } else {
        navigator.clipboard.writeText(url).then(() => showToast('Link an kwafa!'));
    }
}

function togglePostMenu(pid) {
    document.querySelectorAll('.post-menu').forEach(m => {
        if (m.id !== 'pmenu-' + pid) m.classList.remove('open');
    });
    document.getElementById('pmenu-' + pid)?.classList.toggle('open');
}
document.addEventListener('click', e => {
    if (!e.target.closest('.post-options') && !e.target.closest('.post-menu'))
        document.querySelectorAll('.post-menu').forEach(m => m.classList.remove('open'));
});

// ─────────────────────────────────────────────
// COMPOSER
// ─────────────────────────────────────────────
let selectedFile = null;

function previewMedia(input, type) {
    const file = input.files[0]; if (!file) return;
    selectedFile = file;
    const url  = URL.createObjectURL(file);
    const prev = document.getElementById('media-preview');
    prev.style.display = 'block';
    if (type === 'image') {
        prev.innerHTML = `<img src="${url}" style="max-width:100%;border-radius:10px;max-height:200px;object-fit:contain;">
            <button class="remove-media" onclick="removeMedia()"><i class="fa fa-times"></i></button>`;
    } else {
        prev.innerHTML = `<video src="${url}" controls style="max-width:100%;border-radius:10px;max-height:200px;"></video>
            <button class="remove-media" onclick="removeMedia()"><i class="fa fa-times"></i></button>`;
    }
}
function removeMedia() {
    selectedFile = null;
    document.getElementById('media-preview').style.display = 'none';
    document.getElementById('media-preview').innerHTML = '';
}

async function submitPost() {
    const text = document.getElementById('post-text').value.trim();
    if (!text && !selectedFile) { showToast('Rubuta wani abu ko zaɓi media!'); return; }
    const fd = new FormData();
    fd.append('new_post','1');
    fd.append('content', text);
    if (selectedFile) fd.append('media', selectedFile);
    await fetch('home.php', {method:'POST', body:fd});
    document.getElementById('post-text').value = '';
    removeMedia();
    // Reload feed
    feedPage = 1; feedDone = false;
    document.getElementById('feed-container').innerHTML = '';
    loadFeed();
    showToast('Post an ƙara!');
}

function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 180) + 'px';
}

// ─────────────────────────────────────────────
// VIDEO AUTOPLAY (TikTok/Reel style)
// ─────────────────────────────────────────────
function initVideoObserver() {
    const videos = document.querySelectorAll('.post-video-wrap video:not([data-observed])');
    const obs = new IntersectionObserver((entries) => {
        entries.forEach(en => {
            if (en.isIntersecting && en.intersectionRatio > 0.6) {
                en.target.play().catch(()=>{});
                const ovl = en.target.parentElement.querySelector('.vid-play-overlay');
                if (ovl) ovl.style.opacity = '0';
                // Track view
                const pid = en.target.dataset.pid;
                if (pid) fetch('home.php',{method:'POST',
                    headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body:`action=track&post_id=${pid}`});
            } else {
                en.target.pause();
                const ovl = en.target.parentElement.querySelector('.vid-play-overlay');
                if (ovl) ovl.style.opacity = '1';
            }
        });
    }, {threshold: 0.6});
    videos.forEach(v => { obs.observe(v); v.setAttribute('data-observed','1'); });
}
function togglePlay(vid) {
    if (vid.paused) { vid.play(); } else { vid.pause(); }
}

// ─────────────────────────────────────────────
// MEDIA LIGHTBOX
// ─────────────────────────────────────────────
function openMedia(type, src) {
    const box = document.getElementById('lightbox');
    const cnt = document.getElementById('lightbox-content');
    if (type === 'image') {
        cnt.innerHTML = `<img src="${src}" onclick="event.stopPropagation()">`;
    } else {
        cnt.innerHTML = `<video src="${src}" controls autoplay style="max-width:96%;max-height:96%;border-radius:8px;" onclick="event.stopPropagation()"></video>`;
    }
    box.classList.add('open');
}
function closeLightbox() { document.getElementById('lightbox').classList.remove('open'); }

// ─────────────────────────────────────────────
// PROFILE POPUP
// ─────────────────────────────────────────────
async function showProfilePopup(uid) {
    const popup = document.getElementById('profile-popup');
    popup.classList.add('open');
    document.getElementById('pp-name').textContent = '...';
    document.getElementById('pp-bio').textContent  = '';
    document.getElementById('pp-stats').innerHTML  = '<div class="pp-stat"><div class="n">...</div><div class="l">Posts</div></div>';
    document.getElementById('pp-actions').innerHTML= '';
    const r = await fetch(`profile.php?id=${uid}&json=1`);
    const u = await r.json();
    document.getElementById('pp-avatar').src         = u.profile_pic ? 'uploads/' + u.profile_pic : 'assets/default.png';
    document.getElementById('pp-name').textContent   = u.username;
    document.getElementById('pp-role').textContent   = (u.role||'').replace(/_/g,' ').toUpperCase();
    document.getElementById('pp-bio').textContent    = u.bio || '';
    document.getElementById('pp-stats').innerHTML    = `
        <div class="pp-stat"><div class="n">${u.posts}</div><div class="l">Posts</div></div>
        <div class="pp-stat"><div class="n">${u.followers}</div><div class="l">Mabiya</div></div>
        <div class="pp-stat"><div class="n">${u.following}</div><div class="l">Biyo</div></div>
    `;
    const followLabel = u.i_follow ? '<i class="fa fa-check"></i> Biyo' : '<i class="fa fa-user-plus"></i> Bi';
    const followCls   = u.i_follow ? 'following' : '';
    document.getElementById('pp-actions').innerHTML = `
        <button class="pp-btn pp-btn-follow ${followCls}" id="pp-follow-btn" onclick="followUser(${uid}, this)">
            ${followLabel}</button>
        <button class="pp-btn pp-btn-msg" onclick="location.href='sakon.php?to=${uid}'">
            <i class="fa fa-comment"></i> Saƙo</button>
        <button class="pp-btn pp-btn-profile" onclick="location.href='profile.php?id=${uid}'">
            <i class="fa fa-user"></i> Profile</button>
    `;
    // Video call / Voice call buttons
    document.getElementById('pp-actions').innerHTML += `
        <button class="pp-btn" style="background:#1a1a1a;color:#2ecc71;border:1px solid #2ecc71;"
            onclick="startCall(${uid},'${u.username}','voice')">
            <i class="fa fa-phone"></i></button>
        <button class="pp-btn" style="background:#1a1a1a;color:var(--accent);border:1px solid var(--accent);"
            onclick="startCall(${uid},'${u.username}','video')">
            <i class="fa fa-video"></i></button>
    `;
}
function closeProfilePopup(e) {
    if (e.target === document.getElementById('profile-popup'))
        document.getElementById('profile-popup').classList.remove('open');
}

function startCall(uid, uname, type) {
    document.getElementById('profile-popup').classList.remove('open');
    window.location.href = `call.php?to=${uid}&type=${type}`;
}

// ─────────────────────────────────────────────
// NOTIFICATIONS
// ─────────────────────────────────────────────
function toggleNotif(e) {
    e.preventDefault();
    document.getElementById('notif-panel').classList.toggle('open');
    const b1 = document.getElementById('notif-badge');
    const b2 = document.getElementById('notif-badge-m');
    if (b1) b1.remove();
    if (b2) b2.remove();
}
document.addEventListener('click', e => {
    if (!e.target.closest('#notif-panel') && !e.target.closest('[onclick*="toggleNotif"]'))
        document.getElementById('notif-panel').classList.remove('open');
});

// ─────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────
function showToast(msg) {
    let t = document.getElementById('toast');
    if (!t) { t = document.createElement('div'); t.id='toast';
        t.style.cssText='position:fixed;top:70px;left:50%;transform:translateX(-50%);background:#1a1a1a;color:#fff;padding:10px 22px;border-radius:20px;font-size:.85rem;z-index:99999;border:1px solid var(--accent);opacity:0;transition:.3s;pointer-events:none;';
        document.body.appendChild(t); }
    t.textContent = msg;
    t.style.opacity = '1';
    setTimeout(() => { t.style.opacity = '0'; }, 2500);
}
</script>
</body>
</html>
