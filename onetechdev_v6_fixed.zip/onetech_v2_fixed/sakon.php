<?php
require_once 'inc/config.php';
if (!isLoggedIn()) redirect('index.php');

$uid      = $_SESSION['user_id'];
$username = $_SESSION['username'];

// ── AJAX: fetch new messages (polling) ──────────────────────────────
if (isset($_GET['poll']) && isset($_GET['with'])) {
    $with     = (int)$_GET['with'];
    $last_id  = (int)($_GET['last_id'] ?? 0);
    $msgs = $conn->query("
        SELECT m.*, u.username, u.profile_pic
        FROM messages m JOIN users u ON m.sender_id=u.id
        WHERE ((m.sender_id=$uid AND m.receiver_id=$with)
            OR (m.sender_id=$with AND m.receiver_id=$uid))
        AND m.id > $last_id
        ORDER BY m.created_at ASC
    ");
    $conn->query("UPDATE messages SET is_read=1 WHERE sender_id=$with AND receiver_id=$uid");
    $out = [];
    while($r=$msgs->fetch_assoc()) $out[]=$r;
    echo json_encode($out); exit;
}

// ── AJAX: fetch group messages ────────────────────────────────────────
if (isset($_GET['gpoll']) && isset($_GET['gid'])) {
    $gid     = (int)$_GET['gid'];
    $last_id = (int)($_GET['last_id'] ?? 0);
    $msgs = $conn->query("
        SELECT gm.*, u.username, u.profile_pic
        FROM group_messages gm JOIN users u ON gm.sender_id=u.id
        WHERE gm.group_id=$gid AND gm.id > $last_id
        ORDER BY gm.created_at ASC
    ");
    $out=[];
    while($r=$msgs->fetch_assoc()) $out[]=$r;
    echo json_encode($out); exit;
}

// ── AJAX: send direct message ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_msg'])) {
    $to      = (int)$_POST['to'];
    $msg     = clean($conn, $_POST['message'] ?? '');
    $mtype   = 'text';
    $media   = '';

    if (isset($_FILES['media_file']) && $_FILES['media_file']['error']===0) {
        $ext  = strtolower(pathinfo($_FILES['media_file']['name'], PATHINFO_EXTENSION));
        $ai   = ['jpg','jpeg','png','gif','webp'];
        $av   = ['mp4','webm','mov'];
        $aa   = ['mp3','ogg','wav','m4a'];
        $af   = ['pdf','zip','doc','docx','txt'];
        $name = uniqid().'.'.$ext;
        $dest = 'uploads/'.$name;
        move_uploaded_file($_FILES['media_file']['tmp_name'], $dest);
        $media = $dest;
        if (in_array($ext,$ai))      $mtype='image';
        elseif (in_array($ext,$av))  $mtype='video';
        elseif (in_array($ext,$aa))  $mtype='audio';
        elseif (in_array($ext,$af))  $mtype='file';
    }

    $conn->query("INSERT INTO messages (sender_id,receiver_id,message,media_url,media_type)
                  VALUES ($uid,$to,'$msg','$media','$mtype')");
    $newid = $conn->insert_id;

    // Notification
    $conn->query("INSERT INTO notifications (user_id,from_user_id,type,message)
                  VALUES ($to,$uid,'message','Ya aiko maka saƙo')");

    $row = $conn->query("SELECT m.*,u.username,u.profile_pic FROM messages m
                         JOIN users u ON m.sender_id=u.id WHERE m.id=$newid")->fetch_assoc();
    echo json_encode($row); exit;
}

// ── AJAX: send group message ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_group_msg'])) {
    $gid  = (int)$_POST['gid'];
    $msg  = clean($conn, $_POST['message'] ?? '');
    $mtype= 'text'; $media='';

    if (isset($_FILES['media_file']) && $_FILES['media_file']['error']===0) {
        $ext  = strtolower(pathinfo($_FILES['media_file']['name'], PATHINFO_EXTENSION));
        $name = uniqid().'.'.$ext;
        $dest = 'uploads/'.$name;
        move_uploaded_file($_FILES['media_file']['tmp_name'], $dest);
        $media = $dest;
        $ai=['jpg','jpeg','png','gif','webp']; $av=['mp4','webm','mov']; $aa=['mp3','ogg','wav','m4a'];
        if(in_array($ext,$ai)) $mtype='image';
        elseif(in_array($ext,$av)) $mtype='video';
        elseif(in_array($ext,$aa)) $mtype='audio';
        else $mtype='file';
    }

    $conn->query("INSERT INTO group_messages (group_id,sender_id,message,media_url,media_type)
                  VALUES ($gid,$uid,'$msg','$media','$mtype')");
    $newid=$conn->insert_id;
    $row=$conn->query("SELECT gm.*,u.username,u.profile_pic FROM group_messages gm
                       JOIN users u ON gm.sender_id=u.id WHERE gm.id=$newid")->fetch_assoc();
    echo json_encode($row); exit;
}

// ── AJAX: create group ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_group'])) {
    $gname = clean($conn, $_POST['gname'] ?? '');
    $desc  = clean($conn, $_POST['gdesc'] ?? '');
    if (!empty($gname)) {
        $conn->query("INSERT INTO group_chats (name,description,created_by) VALUES ('$gname','$desc',$uid)");
        $gid = $conn->insert_id;
        $conn->query("INSERT INTO group_members (group_id,user_id,role) VALUES ($gid,$uid,'admin')");
        // Add selected members
        if (!empty($_POST['members'])) {
            foreach ((array)$_POST['members'] as $mid) {
                $mid=(int)$mid;
                if($mid!=$uid) $conn->query("INSERT INTO group_members (group_id,user_id) VALUES ($gid,$mid)");
            }
        }
        echo json_encode(['success'=>true,'gid'=>$gid,'name'=>$gname]); exit;
    }
    echo json_encode(['success'=>false]); exit;
}

// ── PAGE LOAD DATA ────────────────────────────────────────────────────
// All users for DM list
$users = $conn->query("
    SELECT u.id, u.username, u.profile_pic, u.role,
           (SELECT COUNT(*) FROM messages WHERE sender_id=u.id AND receiver_id=$uid AND is_read=0) as unread
    FROM users u WHERE u.id != $uid
    ORDER BY unread DESC, u.username ASC
");

// My groups
$groups = $conn->query("
    SELECT gc.* FROM group_chats gc
    JOIN group_members gm ON gc.id=gm.group_id
    WHERE gm.user_id=$uid ORDER BY gc.created_at DESC
");

// All users for group creation
$allUsers = $conn->query("SELECT id,username,profile_pic FROM users WHERE id!=$uid");

$me = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Saƙo - Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{background:#0a0a0a;color:white;height:100vh;display:flex;flex-direction:column;overflow:hidden;}

/* TOP NAV */
.topnav{background:#111;border-bottom:1px solid #222;display:flex;justify-content:space-between;
    align-items:center;padding:10px 20px;flex-shrink:0;}
.topnav .logo{color:#00d4ff;font-weight:800;font-size:1.2rem;text-decoration:none;}
.topnav a{color:#ccc;text-decoration:none;font-size:1.1rem;margin-left:15px;transition:0.3s;}
.topnav a:hover{color:#00d4ff;}

/* CHAT LAYOUT */
.chat-layout{display:flex;flex:1;overflow:hidden;}

/* SIDEBAR */
.chat-sidebar{
    width:300px;background:#111;border-right:1px solid #222;
    display:flex;flex-direction:column;flex-shrink:0;
}
@media(max-width:700px){
    /* Show sidebar by default on mobile */
    .chat-sidebar{width:100%;display:flex;}
    .chat-sidebar.mobile-hidden{display:none;}
    /* Hide chat main until user selects a conversation */
    .chat-main{display:none;width:100%;}
    .chat-main.mobile-open{display:flex;}
    /* Back button in chat header */
    .back-btn{display:flex !important;}
    /* Full height layout fix */
    .chat-layout{height:calc(100vh - 55px);}
    /* Pad for bottom nav */
    body{padding-bottom:65px;}
}
@media(min-width:701px){
    .back-btn{display:none !important;}
}
.sidebar-header{padding:15px;border-bottom:1px solid #222;display:flex;justify-content:space-between;align-items:center;}
.sidebar-header h3{color:#00d4ff;font-size:1rem;}
.sidebar-tabs{display:flex;border-bottom:1px solid #222;}
.stab{flex:1;padding:10px;text-align:center;cursor:pointer;color:#666;border:none;background:none;font-size:0.85rem;transition:0.3s;}
.stab.active{color:#00d4ff;border-bottom:2px solid #00d4ff;}
.chat-search{padding:10px 15px;border-bottom:1px solid #1a1a1a;}
.chat-search input{width:100%;background:#1a1a1a;border:1px solid #333;border-radius:20px;
    padding:8px 15px;color:white;outline:none;font-size:0.85rem;}
.chat-search input:focus{border-color:#00d4ff;}
.chat-list{flex:1;overflow-y:auto;}
.chat-item{
    display:flex;align-items:center;gap:12px;padding:12px 15px;
    cursor:pointer;border-bottom:1px solid #1a1a1a;transition:0.3s;
}
.chat-item:hover,.chat-item.active{background:rgba(0,212,255,0.07);}
.chat-item img{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid #333;flex-shrink:0;}
.chat-item .info{flex:1;min-width:0;}
.chat-item .info strong{display:block;font-size:0.9rem;color:white;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.chat-item .info small{color:#666;font-size:0.75rem;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.chat-item .badge{background:#00d4ff;color:#000;border-radius:50%;width:20px;height:20px;
    display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:bold;flex-shrink:0;}
.new-group-btn{margin:10px 15px;background:rgba(0,212,255,0.1);border:1px dashed #00d4ff;
    color:#00d4ff;padding:10px;border-radius:8px;cursor:pointer;width:calc(100% - 30px);
    font-size:0.85rem;transition:0.3s;}
.new-group-btn:hover{background:rgba(0,212,255,0.2);}

/* MAIN CHAT AREA */
.chat-main{flex:1;display:flex;flex-direction:column;background:#0d0d0d;}
.chat-empty{flex:1;display:flex;align-items:center;justify-content:center;
    flex-direction:column;gap:15px;color:#333;}
.chat-empty i{font-size:4rem;}
.chat-topbar{
    padding:12px 20px;background:#111;border-bottom:1px solid #222;
    display:flex;align-items:center;gap:12px;flex-shrink:0;
}
.chat-topbar img{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid #00d4ff;}
.chat-topbar .info strong{display:block;font-size:0.95rem;}
.chat-topbar .info small{color:#00d4ff;font-size:0.75rem;}
.chat-topbar .actions{margin-left:auto;display:flex;gap:15px;}
.chat-topbar .actions button{background:none;border:none;color:#666;font-size:1rem;cursor:pointer;transition:0.3s;}
.chat-topbar .actions button:hover{color:#00d4ff;}

/* MESSAGES */
.messages-area{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:10px;}
.msg-bubble{max-width:70%;display:flex;flex-direction:column;}
.msg-bubble.mine{align-self:flex-end;align-items:flex-end;}
.msg-bubble.theirs{align-self:flex-start;align-items:flex-start;}
.msg-bubble .bubble-inner{
    padding:10px 14px;border-radius:18px;font-size:0.9rem;line-height:1.5;word-break:break-word;
}
.msg-bubble.mine .bubble-inner{background:linear-gradient(135deg,#00d4ff,#0099cc);color:#000;border-bottom-right-radius:4px;}
.msg-bubble.theirs .bubble-inner{background:#1e1e1e;color:#ddd;border-bottom-left-radius:4px;}
.msg-bubble .meta{font-size:0.7rem;color:#555;margin-top:3px;padding:0 5px;}
.msg-bubble .sender-name{font-size:0.75rem;color:#00d4ff;font-weight:600;margin-bottom:3px;padding:0 5px;}
.msg-media img{max-width:220px;border-radius:12px;cursor:pointer;}
.msg-media video,.msg-media audio{max-width:220px;border-radius:12px;}
.msg-media .file-card{
    background:#1a1a1a;border:1px solid #333;border-radius:10px;
    padding:10px 14px;display:flex;align-items:center;gap:10px;
    color:#ccc;font-size:0.85rem;text-decoration:none;
}
.msg-media .file-card i{color:#00d4ff;font-size:1.3rem;}

/* INPUT BAR */
.chat-input-bar{
    padding:12px 20px;background:#111;border-top:1px solid #222;
    display:flex;align-items:center;gap:10px;flex-shrink:0;
}
.chat-input-bar textarea{
    flex:1;background:#1a1a1a;border:1px solid #333;border-radius:20px;
    color:white;padding:10px 16px;resize:none;outline:none;
    font-size:0.9rem;max-height:120px;transition:0.3s;
}
.chat-input-bar textarea:focus{border-color:#00d4ff;}
.input-actions{display:flex;gap:8px;align-items:center;}
.input-actions label,.input-actions button{
    background:none;border:none;color:#666;font-size:1.1rem;
    cursor:pointer;transition:0.3s;padding:5px;
}
.input-actions label:hover,.input-actions button:hover{color:#00d4ff;}
.input-actions input[type=file]{display:none;}
.send-btn{
    background:#00d4ff;color:#000;border:none;border-radius:50%;
    width:42px;height:42px;font-size:1.1rem;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    transition:0.3s;flex-shrink:0;
}
.send-btn:hover{transform:scale(1.1);}

/* MEDIA ATTACH PREVIEW */
#attach-preview{padding:0 20px 10px;background:#111;}
#attach-preview .prev-inner{
    background:#1a1a1a;border-radius:10px;padding:8px 12px;
    display:flex;align-items:center;gap:10px;font-size:0.85rem;color:#ccc;
}
#attach-preview img{height:50px;border-radius:8px;}
#attach-preview .rm{background:none;border:none;color:#f55;cursor:pointer;margin-left:auto;}

/* CREATE GROUP MODAL */
.modal-overlay{display:none;position:fixed;top:0;left:0;width:100%;height:100%;
    background:rgba(0,0,0,0.85);z-index:9000;justify-content:center;align-items:center;}
.modal-overlay.open{display:flex;}
.modal-box{background:#111;border:2px solid #00d4ff;border-radius:20px;padding:30px;
    width:90%;max-width:450px;max-height:85vh;overflow-y:auto;}
.modal-box h3{color:#00d4ff;margin-bottom:20px;}
.modal-box input,.modal-box textarea{
    width:100%;background:#1a1a1a;border:1px solid #333;border-radius:8px;
    color:white;padding:10px;margin-bottom:12px;outline:none;font-size:0.9rem;
}
.modal-box input:focus,.modal-box textarea:focus{border-color:#00d4ff;}
.members-list{max-height:200px;overflow-y:auto;border:1px solid #333;border-radius:8px;margin-bottom:12px;}
.member-check{display:flex;align-items:center;gap:10px;padding:10px;border-bottom:1px solid #1a1a1a;cursor:pointer;}
.member-check:hover{background:#1a1a1a;}
.member-check img{width:32px;height:32px;border-radius:50%;object-fit:cover;}
.member-check input[type=checkbox]{accent-color:#00d4ff;}
.modal-box button[type=submit]{
    background:#00d4ff;color:#000;font-weight:700;border:none;
    padding:12px;border-radius:8px;cursor:pointer;width:100%;font-size:1rem;
}
.modal-close{background:none;border:none;color:#f55;font-size:1.5rem;float:right;cursor:pointer;margin-top:-10px;}

/* VOICE/VIDEO CALL PLACEHOLDER */
.call-bar{
    display:none;position:fixed;bottom:90px;right:20px;
    background:#111;border:2px solid #00d4ff;border-radius:15px;
    padding:15px;z-index:8000;min-width:220px;text-align:center;
}
.call-bar.open{display:block;}
.call-bar h4{color:#00d4ff;margin-bottom:10px;}
.call-bar .call-btns{display:flex;justify-content:center;gap:15px;}
.call-btns button{width:50px;height:50px;border-radius:50%;border:none;cursor:pointer;font-size:1.2rem;transition:0.3s;}
.call-accept{background:#0f0;color:#000;}
.call-decline{background:#f55;color:white;}
.call-end{background:#f55;color:white;}
</style>
</head>
<body>

<!-- TOP NAV -->
<nav class="topnav">
    <a href="index.php" class="logo"><i class="fa fa-code"></i> Onetech Dev</a>
    <div>
        <a href="home.php"><i class="fa fa-home"></i></a>
        <a href="sakon.php" style="color:#00d4ff;"><i class="fa fa-comment"></i></a>
        <a href="logout.php"><i class="fa fa-sign-out-alt" style="color:#f55;"></i></a>
    </div>
</nav>

<!-- CHAT LAYOUT -->
<div class="chat-layout">

    <!-- SIDEBAR -->
    <div class="chat-sidebar" id="chat-sidebar">
        <div class="sidebar-header">
            <h3><i class="fa fa-comment"></i> Saƙo</h3>
            <span style="color:#aaa;font-size:0.8rem;"><?=$username?></span>
        </div>
        <div class="sidebar-tabs">
            <button class="stab active" onclick="showTab('dms',this)">Direct</button>
            <button class="stab" onclick="showTab('groups',this)">Groups</button>
        </div>
        <div class="chat-search"><input type="text" placeholder="Nema..." id="search-input" oninput="filterChats()"></div>

        <!-- DM LIST -->
        <div class="chat-list" id="dm-list">
            <?php $users->data_seek(0); while($u=$users->fetch_assoc()): ?>
            <div class="chat-item" id="dm-<?=$u['id']?>" onclick="openDM(<?=$u['id']?>,'<?=htmlspecialchars($u['username'])?>','<?=$u['profile_pic']?>','<?=str_replace('_',' ',ucfirst($u['role']))?>') ">
                <img src="<?=$u['profile_pic']?>" alt="<?=$u['username']?>">
                <div class="info">
                    <strong><?=$u['username']?></strong>
                    <small><?=str_replace('_',' ',ucfirst($u['role']))?></small>
                </div>
                <?php if($u['unread']>0): ?>
                <div class="badge"><?=$u['unread']?></div>
                <?php endif; ?>
            </div>
            <?php endwhile; ?>
        </div>

        <!-- GROUPS LIST -->
        <div class="chat-list" id="groups-list" style="display:none;">
            <button class="new-group-btn" onclick="openGroupModal()">
                <i class="fa fa-plus"></i> Sabon Group
            </button>
            <?php $groups->data_seek(0); while($g=$groups->fetch_assoc()): ?>
            <div class="chat-item" onclick="openGroup(<?=$g['id']?>,'<?=htmlspecialchars($g['name'])?>','<?=$g['group_pic']?>')">
                <img src="<?=$g['group_pic']?>" alt="<?=$g['name']?>">
                <div class="info">
                    <strong><?=$g['name']?></strong>
                    <small><?=$g['description']?></small>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- MAIN CHAT -->
    <div class="chat-main" id="chat-main">
        <div class="chat-empty" id="chat-empty">
            <i class="fa fa-comment-dots"></i>
            <p>Zaɓi tattaunawa don fara saƙo</p>
        </div>

        <!-- ACTIVE CHAT -->
        <div id="active-chat" style="display:none;flex:1;flex-direction:column;">
            <div class="chat-topbar" id="chat-topbar">
                <!-- Back button for mobile -->
                <button class="back-btn" onclick="mobileBackToList()" title="Koma" style="background:none;border:none;color:#00d4ff;font-size:1.3rem;padding:0 10px 0 0;cursor:pointer;">
                    <i class="fa fa-arrow-left"></i>
                </button>
                <img id="chat-pic" src="" alt="">
                <div class="info">
                    <strong id="chat-name"></strong>
                    <small id="chat-role"></small>
                </div>
                <div class="actions">
                    <button onclick="startCall('voice')" title="Voice Call"><i class="fa fa-phone"></i></button>
                    <button onclick="startCall('video')" title="Video Call"><i class="fa fa-video"></i></button>
                    <button onclick="viewProfile()" title="View Profile"><i class="fa fa-user"></i></button>
                </div>
            </div>

            <div class="messages-area" id="messages-area"></div>

            <!-- ATTACH PREVIEW -->
            <div id="attach-preview" style="display:none;">
                <div class="prev-inner">
                    <span id="attach-name"></span>
                    <button class="rm" onclick="clearAttach()"><i class="fa fa-times"></i></button>
                </div>
            </div>

            <!-- INPUT BAR -->
            <div class="chat-input-bar">
                <div class="input-actions">
                    <label title="Attach file/image/video">
                        <i class="fa fa-paperclip"></i>
                        <input type="file" id="attach-file" onchange="previewAttach(this)" accept="image/*,video/*,audio/*,.pdf,.zip,.doc,.docx,.txt">
                    </label>
                    <button type="button" id="voice-btn" onclick="toggleVoiceRecord()" title="Rikodin Murya" style="background:none;border:none;color:#aaa;font-size:1.2rem;cursor:pointer;padding:0 4px;">
                        <i class="fa fa-microphone" id="voice-icon"></i>
                    </button>
                </div>
                <textarea id="msg-input" placeholder="Rubuta saƙo..." rows="1"
                    onkeydown="handleEnter(event)" oninput="autoResize(this)"></textarea>
                <button class="send-btn" onclick="sendMessage()"><i class="fa fa-paper-plane"></i></button>
            </div>
        </div>
    </div>
</div>

<!-- CREATE GROUP MODAL -->
<div class="modal-overlay" id="group-modal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeGroupModal()">&#x2715;</button>
        <h3><i class="fa fa-users"></i> Sabon Group Chat</h3>
        <form id="create-group-form">
            <input type="text" name="gname" placeholder="Suna na Group" required>
            <textarea name="gdesc" placeholder="Bayani (optional)" rows="2"></textarea>
            <p style="color:#aaa;font-size:0.8rem;margin-bottom:8px;">Zaɓi Members:</p>
            <div class="members-list">
                <?php $allUsers->data_seek(0); while($u=$allUsers->fetch_assoc()): ?>
                <label class="member-check">
                    <input type="checkbox" name="members[]" value="<?=$u['id']?>">
                    <img src="<?=$u['profile_pic']?>" alt="">
                    <span><?=$u['username']?></span>
                </label>
                <?php endwhile; ?>
            </div>
            <button type="submit">Ƙirƙiri Group <i class="fa fa-arrow-right"></i></button>
        </form>
    </div>
</div>

<!-- CALL BAR (Placeholder - WebRTC zai bukaci server) -->
<div class="call-bar" id="call-bar">
    <h4 id="call-title">📞 Voice Call</h4>
    <p id="call-status" style="color:#aaa;font-size:0.8rem;margin-bottom:10px;">Calling...</p>
    <div class="call-btns">
        <button class="call-end" onclick="endCall()" title="End Call"><i class="fa fa-phone-slash"></i></button>
    </div>
</div>

<script>
// ── STATE ─────────────────────────────────────────────────────────────
let currentDM   = null;  // user id
let currentGID  = null;  // group id
let currentType = null;  // 'dm' | 'group'
let currentName = '';
let lastMsgId   = 0;
let pollTimer   = null;
let attachFile  = null;
let currentProfileId = null;

// ── TABS ──────────────────────────────────────────────────────────────
function showTab(tab, btn) {
    document.querySelectorAll('.stab').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('dm-list').style.display    = tab==='dms'    ? 'block' : 'none';
    document.getElementById('groups-list').style.display = tab==='groups' ? 'block' : 'none';
}

// ── SEARCH ────────────────────────────────────────────────────────────
function filterChats() {
    const q = document.getElementById('search-input').value.toLowerCase();
    document.querySelectorAll('.chat-item').forEach(el=>{
        const name = el.querySelector('strong')?.textContent.toLowerCase() || '';
        el.style.display = name.includes(q) ? 'flex' : 'none';
    });
}

// ── OPEN DM ───────────────────────────────────────────────────────────
function openDM(uid, uname, pic, role) {
    clearInterval(pollTimer);
    currentDM   = uid; currentGID=null; currentType='dm';
    currentName = uname; currentProfileId=uid;
    lastMsgId   = 0;
    document.getElementById('chat-empty').style.display='none';
    const ac=document.getElementById('active-chat');
    ac.style.display='flex'; ac.style.flexDirection='column';
    document.getElementById('chat-pic').src    = pic;
    document.getElementById('chat-name').textContent  = uname;
    document.getElementById('chat-role').textContent  = role;
    document.querySelectorAll('.chat-item').forEach(i=>i.classList.remove('active'));
    document.getElementById('dm-'+uid)?.classList.add('active');
    // Clear unread badge
    const badge=document.querySelector('#dm-'+uid+' .badge');
    if(badge) badge.remove();
    document.getElementById('messages-area').innerHTML='';
    pollMessages();
    pollTimer = setInterval(pollMessages, 2500);
    // Mobile: hide sidebar, show chat main
    mobileShowChat();
}

// ── OPEN GROUP ────────────────────────────────────────────────────────
function openGroup(gid, gname, pic) {
    clearInterval(pollTimer);
    currentGID=gid; currentDM=null; currentType='group';
    currentName=gname; currentProfileId=null;
    lastMsgId=0;
    document.getElementById('chat-empty').style.display='none';
    const ac=document.getElementById('active-chat');
    ac.style.display='flex'; ac.style.flexDirection='column';
    document.getElementById('chat-pic').src=pic;
    document.getElementById('chat-name').textContent=gname;
    document.getElementById('chat-role').textContent='Group Chat';
    document.getElementById('messages-area').innerHTML='';
    pollMessages();
    pollTimer=setInterval(pollMessages,2500);
    // Mobile: hide sidebar, show chat main
    mobileShowChat();
}

// ── MOBILE HELPERS ────────────────────────────────────────────────────
function mobileShowChat() {
    if(window.innerWidth <= 700) {
        document.querySelector('.chat-sidebar').classList.add('mobile-hidden');
        const cm = document.getElementById('chat-main');
        cm.classList.add('mobile-open');
        cm.style.display='flex';
    }
}
function mobileBackToList() {
    document.querySelector('.chat-sidebar').classList.remove('mobile-hidden');
    const cm = document.getElementById('chat-main');
    cm.classList.remove('mobile-open');
    cm.style.display='none';
    clearInterval(pollTimer);
}

// ── POLL MESSAGES ─────────────────────────────────────────────────────
function pollMessages() {
    let url = '';
    if(currentType==='dm')    url=`sakon.php?poll=1&with=${currentDM}&last_id=${lastMsgId}`;
    if(currentType==='group') url=`sakon.php?gpoll=1&gid=${currentGID}&last_id=${lastMsgId}`;
    if(!url) return;
    fetch(url).then(r=>r.json()).then(msgs=>{
        msgs.forEach(m=>{
            appendMessage(m);
            lastMsgId=Math.max(lastMsgId,m.id);
        });
        if(msgs.length>0) scrollBottom();
    });
}

// ── APPEND MESSAGE ────────────────────────────────────────────────────
function appendMessage(m) {
    const area  = document.getElementById('messages-area');
    const myUid = <?=$uid?>;
    const mine  = parseInt(m.sender_id)===myUid;
    const cls   = mine ? 'mine' : 'theirs';
    const time  = new Date(m.created_at).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});

    let mediaHTML = '';
    if(m.media_url && m.media_type!=='text') {
        const url = m.media_url;
        if(m.media_type==='image') {
            mediaHTML=`<div class="msg-media"><img src="${url}" onclick="window.open('${url}')"></div>`;
        } else if(m.media_type==='video') {
            mediaHTML=`<div class="msg-media"><video src="${url}" controls></video></div>`;
        } else if(m.media_type==='audio') {
            mediaHTML=`<div class="msg-media"><audio src="${url}" controls></audio></div>`;
        } else {
            const fname=url.split('/').pop();
            mediaHTML=`<div class="msg-media"><a class="file-card" href="${url}" download><i class="fa fa-file"></i>${fname}</a></div>`;
        }
    }

    const groupSender = (!mine && currentType==='group')
        ? `<div class="sender-name">${m.username}</div>` : '';

    const textHTML = m.message ? `<div class="bubble-inner">${escapeHtml(m.message)}</div>` : '';

    const div=document.createElement('div');
    div.className=`msg-bubble ${cls}`;
    div.id='msg-'+m.id;
    div.innerHTML=`${groupSender}${mediaHTML}${textHTML}<div class="meta">${time}</div>`;
    area.appendChild(div);
}

// ── SEND MESSAGE ──────────────────────────────────────────────────────
function sendMessage() {
    const input = document.getElementById('msg-input');
    const msg   = input.value.trim();
    if(!msg && !attachFile) return;

    const fd = new FormData();
    if(currentType==='dm') {
        fd.append('send_msg',1); fd.append('to',currentDM);
    } else {
        fd.append('send_group_msg',1); fd.append('gid',currentGID);
    }
    fd.append('message', msg);
    if(attachFile) fd.append('media_file', attachFile);

    input.value=''; input.style.height='auto'; clearAttach();

    fetch('sakon.php',{method:'POST',body:fd}).then(r=>r.json()).then(m=>{
        if(m.id) { appendMessage(m); lastMsgId=Math.max(lastMsgId,m.id); scrollBottom(); }
    });
}

function handleEnter(e) {
    if(e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
    el.style.height='auto';
    el.style.height=(el.scrollHeight)+'px';
}

// ── ATTACH FILE ───────────────────────────────────────────────────────
function previewAttach(input) {
    attachFile = input.files[0];
    if(!attachFile) return;
    const prev=document.getElementById('attach-preview');
    prev.style.display='block';
    document.getElementById('attach-name').textContent=attachFile.name;
}
function clearAttach() {
    attachFile=null;
    document.getElementById('attach-preview').style.display='none';
    document.getElementById('attach-file').value='';
}

// ── VOICE RECORDING ───────────────────────────────────────────────────
let mediaRecorder = null;
let audioChunks   = [];
let isRecording   = false;

async function toggleVoiceRecord() {
    const btn  = document.getElementById('voice-btn');
    const icon = document.getElementById('voice-icon');
    if (!isRecording) {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({audio:true});
            mediaRecorder = new MediaRecorder(stream);
            audioChunks   = [];
            mediaRecorder.ondataavailable = e => { if(e.data.size>0) audioChunks.push(e.data); };
            mediaRecorder.onstop = () => {
                const blob = new Blob(audioChunks, {type:'audio/webm'});
                const file = new File([blob], 'voice_' + Date.now() + '.webm', {type:'audio/webm'});
                attachFile  = file;
                document.getElementById('attach-preview').style.display='flex';
                document.getElementById('attach-name').textContent = '🎤 Saƙon Murya (' + Math.round(blob.size/1024) + ' KB)';
                stream.getTracks().forEach(t=>t.stop());
            };
            mediaRecorder.start();
            isRecording = true;
            icon.className = 'fa fa-stop';
            btn.style.color = '#ff4444';
            btn.title = 'Tsayar da Rikodi';
        } catch(err) {
            alert('Ba a yarda da microphone ba: ' + err.message);
        }
    } else {
        mediaRecorder.stop();
        isRecording = false;
        icon.className = 'fa fa-microphone';
        btn.style.color = '#aaa';
        btn.title = 'Rikodin Murya';
    }
}

// ── CREATE GROUP ──────────────────────────────────────────────────────
function openGroupModal(){ document.getElementById('group-modal').classList.add('open'); }
function closeGroupModal(){ document.getElementById('group-modal').classList.remove('open'); }
document.getElementById('create-group-form').addEventListener('submit',function(e){
    e.preventDefault();
    const fd=new FormData(this);
    fd.append('create_group',1);
    fetch('sakon.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{
        if(data.success){
            closeGroupModal();
            openGroup(data.gid,data.name,'assets/group_default.png');
            // Add to sidebar
            const list=document.getElementById('groups-list');
            const div=document.createElement('div');
            div.className='chat-item';
            div.onclick=()=>openGroup(data.gid,data.name,'assets/group_default.png');
            div.innerHTML=`<img src="assets/group_default.png" style="width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid #333;">
                <div class="info"><strong>${data.name}</strong><small>New Group</small></div>`;
            list.appendChild(div);
        }
    });
});

// ── CALL (UI only — WebRTC needs signaling server) ────────────────────
function startCall(type) {
    const bar=document.getElementById('call-bar');
    document.getElementById('call-title').textContent= type==='voice' ? '📞 Voice Call' : '📹 Video Call';
    document.getElementById('call-status').textContent=`Calling ${currentName}...`;
    bar.classList.add('open');
    // TODO: WebRTC implementation
}
function endCall(){
    document.getElementById('call-bar').classList.remove('open');
}

// ── VIEW PROFILE ──────────────────────────────────────────────────────
function viewProfile(){
    if(currentProfileId) window.location.href='profile.php?id='+currentProfileId;
}

// ── HELPERS ───────────────────────────────────────────────────────────
function scrollBottom(){
    const a=document.getElementById('messages-area');
    a.scrollTop=a.scrollHeight;
}
function escapeHtml(t){
    return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
             .replace(/"/g,'&quot;').replace(/\n/g,'<br>');
}
</script>

<!-- MOBILE BOTTOM NAVIGATION -->
<style>
.mobile-bottom-nav{display:none;position:fixed;bottom:0;left:0;width:100%;background:#111;border-top:1px solid #222;z-index:9999;padding:8px 0 calc(8px + env(safe-area-inset-bottom));}
.mobile-bottom-nav .nav-items{display:flex;justify-content:space-around;align-items:center;}
.mobile-bottom-nav a{display:flex;flex-direction:column;align-items:center;gap:3px;color:#666;text-decoration:none;font-size:0.65rem;padding:6px 10px;border-radius:12px;transition:0.2s;position:relative;}
.mobile-bottom-nav a.active,.mobile-bottom-nav a:hover{color:#00d4ff;}
.mobile-bottom-nav a i{font-size:1.3rem;}
.mobile-bottom-nav a img{width:28px;height:28px;border-radius:50%;object-fit:cover;border:2px solid #333;}
.mobile-bottom-nav a.active img{border-color:#00d4ff;}
@media(max-width:700px){.mobile-bottom-nav{display:block;}.topnav .nav-icons{display:none;}}
</style>
<nav class="mobile-bottom-nav">
    <div class="nav-items">
        <a href="home.php" title="Gida"><i class="fa fa-home"></i><span>Gida</span></a>
        <a href="sakon.php" class="active" title="Sako"><i class="fa fa-comment"></i><span>Sako</span></a>
        <a href="home.php" title="Feed"><i class="fa fa-plus-circle" style="font-size:1.8rem;color:#00d4ff;"></i><span>Post</span></a>
        <a href="home.php#notif" title="Sanarwa"><i class="fa fa-bell"></i><span>Sanarwa</span></a>
        <a href="profile.php?id=<?=$uid?>" title="Profile"><img src="<?=$me['profile_pic']?>" alt="Profile"><span>Ni</span></a>
    </div>
</nav>

</body>
</html>