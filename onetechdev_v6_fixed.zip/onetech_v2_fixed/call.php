<?php
require_once 'inc/config.php';
if (!isLoggedIn()) redirect('index.php');

$my_id    = $_SESSION['user_id'];
$callee_id= (int)($_GET['to']   ?? 0);
$call_type= in_array($_GET['type']??'',['voice','video']) ? $_GET['type'] : 'voice';
$call_type= in_array($call_type,['voice','video']) ? $call_type : 'voice';
$call_id  = (int)($_GET['call'] ?? 0); // incoming call

$me     = $conn->query("SELECT * FROM users WHERE id=$my_id")->fetch_assoc();
$callee = $callee_id ? $conn->query("SELECT * FROM users WHERE id=$callee_id")->fetch_assoc() : null;

// ── AJAX ENDPOINTS ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $act = $_POST['action'] ?? '';

    if ($act === 'initiate') {
        // Caller starts a call
        $to   = (int)($_POST['to'] ?? 0);
        $type = in_array($_POST['type']??'',['voice','video']) ? $_POST['type'] : 'voice';
        $conn->query("INSERT INTO calls (caller_id,callee_id,call_type,status) VALUES ($my_id,$to,'$type','ringing')");
        echo json_encode(['ok'=>true,'call_id'=>$conn->insert_id]);
        exit;
    }
    if ($act === 'offer') {
        $cid = (int)($_POST['call_id']??0);
        $sdp = $conn->real_escape_string($_POST['sdp']??'');
        $conn->query("UPDATE calls SET offer_sdp='$sdp' WHERE id=$cid AND caller_id=$my_id");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'answer') {
        $cid = (int)($_POST['call_id']??0);
        $sdp = $conn->real_escape_string($_POST['sdp']??'');
        $conn->query("UPDATE calls SET answer_sdp='$sdp',status='active',answered_at=NOW() WHERE id=$cid AND callee_id=$my_id");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'ice') {
        $cid  = (int)($_POST['call_id']??0);
        $ice  = $conn->real_escape_string($_POST['ice']??'');
        $role = $_POST['role']??'caller';
        $col  = $role==='caller' ? 'caller_ice' : 'callee_ice';
        $conn->query("UPDATE calls SET $col='$ice' WHERE id=$cid");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'poll') {
        $cid = (int)($_POST['call_id']??0);
        $row = $conn->query("SELECT * FROM calls WHERE id=$cid")->fetch_assoc();
        echo json_encode($row ?: ['status'=>'not_found']); exit;
    }
    if ($act === 'end') {
        $cid = (int)($_POST['call_id']??0);
        $conn->query("UPDATE calls SET status='ended',ended_at=NOW() WHERE id=$cid AND (caller_id=$my_id OR callee_id=$my_id)");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'decline') {
        $cid = (int)($_POST['call_id']??0);
        $conn->query("UPDATE calls SET status='declined',ended_at=NOW() WHERE id=$cid AND callee_id=$my_id");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'missed') {
        $cid = (int)($_POST['call_id']??0);
        $conn->query("UPDATE calls SET status='missed',ended_at=NOW() WHERE id=$cid");
        echo json_encode(['ok'=>true]); exit;
    }
    if ($act === 'check_incoming') {
        // Callee polls for incoming calls
        $row = $conn->query("SELECT c.*,u.username,u.profile_pic FROM calls c
            JOIN users u ON c.caller_id=u.id
            WHERE c.callee_id=$my_id AND c.status='ringing'
            ORDER BY c.started_at DESC LIMIT 1")->fetch_assoc();
        echo json_encode($row ?: ['none'=>true]); exit;
    }
    exit;
}

$callee_name = $callee ? htmlspecialchars($callee['username']) : 'Unknown';
$callee_pic  = $callee && $callee['profile_pic'] ? 'uploads/'.htmlspecialchars($callee['profile_pic']) : 'assets/default.png';
$my_pic      = $me['profile_pic'] ? 'uploads/'.htmlspecialchars($me['profile_pic']) : 'assets/default.png';
$is_video    = $call_type === 'video';
?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=$is_video?'Video':'Voice'?> Call – Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#000;color:#fff;font-family:'Segoe UI',sans-serif;height:100vh;overflow:hidden;}

/* VIDEO BACKGROUNDS */
#remote-video{position:fixed;inset:0;width:100%;height:100%;object-fit:cover;background:#0a0a0a;z-index:1;}
#local-video{position:fixed;bottom:120px;right:16px;width:110px;height:160px;border-radius:14px;
    object-fit:cover;z-index:10;border:2px solid rgba(255,255,255,.3);background:#111;}

/* VOICE CALL BG (hidden in video mode) */
#call-bg{position:fixed;inset:0;z-index:2;display:flex;flex-direction:column;align-items:center;justify-content:center;
    background:linear-gradient(180deg,#0a1628 0%,#0d2137 50%,#091220 100%);}

/* AVATAR / WAVES */
.caller-avatar{width:110px;height:110px;border-radius:50%;object-fit:cover;
    border:4px solid rgba(255,255,255,.3);position:relative;z-index:2;}
.wave-ring{position:absolute;border-radius:50%;border:2px solid rgba(255,255,255,.15);animation:wave 2s ease-out infinite;}
.wave-ring:nth-child(1){width:130px;height:130px;animation-delay:0s;}
.wave-ring:nth-child(2){width:160px;height:160px;animation-delay:.5s;}
.wave-ring:nth-child(3){width:190px;height:190px;animation-delay:1s;}
@keyframes wave{0%{opacity:.5;transform:scale(1);}100%{opacity:0;transform:scale(1.4);}}
.avatar-wrap{position:relative;display:flex;align-items:center;justify-content:center;width:200px;height:200px;}

.caller-name{font-size:1.5rem;font-weight:800;margin:16px 0 6px;z-index:2;text-align:center;}
.call-status{font-size:.9rem;color:rgba(255,255,255,.65);z-index:2;text-align:center;margin-bottom:8px;}
.call-timer{font-size:1.1rem;font-weight:600;color:#2ecc71;z-index:2;display:none;}
.call-type-badge{background:rgba(255,255,255,.1);border-radius:20px;padding:4px 14px;
    font-size:.75rem;color:rgba(255,255,255,.7);z-index:2;margin-top:6px;}

/* CONTROLS */
.call-controls{position:fixed;bottom:0;left:0;right:0;z-index:20;
    padding:24px 20px 38px;display:flex;justify-content:center;gap:22px;align-items:center;
    background:linear-gradient(transparent,rgba(0,0,0,.8));}
.ctrl-btn{width:64px;height:64px;border-radius:50%;border:none;cursor:pointer;
    display:flex;align-items:center;justify-content:center;font-size:1.4rem;transition:.2s;}
.ctrl-btn:hover{transform:scale(1.1);}
.btn-mute{background:rgba(255,255,255,.15);color:#fff;}
.btn-mute.active{background:rgba(255,255,255,.35);}
.btn-speaker{background:rgba(255,255,255,.15);color:#fff;}
.btn-cam{background:rgba(255,255,255,.15);color:#fff;}
.btn-cam.active{background:rgba(255,255,255,.35);}
.btn-end{background:#e74c3c;color:#fff;width:72px;height:72px;}
.btn-end:hover{background:#c0392b;}
.btn-answer{background:#2ecc71;color:#fff;width:72px;height:72px;}
.btn-answer:hover{background:#27ae60;}
.btn-flip{background:rgba(255,255,255,.15);color:#fff;}

/* INCOMING CALL SCREEN */
#incoming-screen{display:none;position:fixed;inset:0;z-index:999;
    background:linear-gradient(180deg,#0a1628 0%,#0d2137 50%,#091220 100%);
    flex-direction:column;align-items:center;justify-content:center;gap:12px;}
#incoming-screen.show{display:flex;}
.inc-avatar{width:100px;height:100px;border-radius:50%;border:4px solid #2ecc71;object-fit:cover;}
.inc-name{font-size:1.3rem;font-weight:800;}
.inc-label{font-size:.85rem;color:rgba(255,255,255,.6);}
.inc-timer{font-size:1rem;color:#e74c3c;font-weight:700;margin-top:4px;}
.inc-controls{display:flex;gap:40px;margin-top:30px;}

/* STATUS OVERLAY */
#status-overlay{display:none;position:fixed;inset:0;z-index:50;align-items:center;justify-content:center;
    background:rgba(0,0,0,.6);flex-direction:column;gap:12px;}
#status-overlay.show{display:flex;}
#status-overlay .so-icon{font-size:3rem;}
#status-overlay .so-text{font-size:1rem;font-weight:700;}
#status-overlay .so-sub{font-size:.82rem;color:rgba(255,255,255,.6);}

/* MISSED / DECLINED */
.call-ended-msg{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
    text-align:center;z-index:999;}
.call-ended-msg h2{font-size:1.4rem;margin-bottom:10px;}
.call-ended-msg p{color:rgba(255,255,255,.65);font-size:.85rem;}
.go-back-btn{margin-top:24px;background:#fff;color:#000;border:none;border-radius:20px;
    padding:12px 30px;font-weight:800;font-size:.9rem;cursor:pointer;}
</style>
</head>
<body>

<!-- REMOTE VIDEO (video call) -->
<video id="remote-video" autoplay playsinline style="display:<?=$is_video?'block':'none'?>;"></video>
<!-- LOCAL VIDEO (video call) -->
<video id="local-video" autoplay playsinline muted style="display:<?=$is_video?'block':'none'?>;"></video>

<!-- VOICE CALL / RINGING SCREEN -->
<div id="call-bg">
    <div class="avatar-wrap">
        <div class="wave-ring" id="wr1"></div>
        <div class="wave-ring" id="wr2"></div>
        <div class="wave-ring" id="wr3"></div>
        <img class="caller-avatar" id="callee-avatar" src="<?=$callee_pic?>" onerror="this.src='assets/default.png'">
    </div>
    <div class="caller-name" id="callee-name"><?=$callee_name?></div>
    <div class="call-status" id="call-status">Ana buga kira...</div>
    <div class="call-timer" id="call-timer">0:00</div>
    <div class="call-type-badge"><i class="fa fa-<?=$is_video?'video':'phone'?>"></i> <?=$is_video?'Video':'Voice'?> Call</div>
</div>

<!-- INCOMING CALL SCREEN (shown if callee) -->
<div id="incoming-screen">
    <img class="inc-avatar" id="inc-avatar" src="" onerror="this.src='assets/default.png'">
    <div class="inc-name" id="inc-name">Kira...</div>
    <div class="inc-label" id="inc-label">Kira ya zo</div>
    <div class="inc-timer" id="inc-timer">10</div>
    <div class="inc-controls">
        <button class="ctrl-btn btn-end" onclick="declineCall()" title="Ƙi">
            <i class="fa fa-phone-slash"></i>
        </button>
        <button class="ctrl-btn btn-answer" onclick="answerCall()" title="Daga">
            <i class="fa fa-phone"></i>
        </button>
    </div>
</div>

<!-- STATUS OVERLAY (missed/declined/ended) -->
<div id="status-overlay">
    <div class="so-icon" id="so-icon"></div>
    <div class="so-text" id="so-text"></div>
    <div class="so-sub" id="so-sub"></div>
    <button class="go-back-btn" onclick="goBack()">Koma</button>
</div>

<!-- CALL CONTROLS -->
<div class="call-controls" id="call-controls">
    <button class="ctrl-btn btn-mute" id="btn-mute" onclick="toggleMute()" title="Shuru">
        <i class="fa fa-microphone"></i>
    </button>
    <?php if($is_video): ?>
    <button class="ctrl-btn btn-cam" id="btn-cam" onclick="toggleCam()" title="Camera">
        <i class="fa fa-video"></i>
    </button>
    <button class="ctrl-btn btn-flip" onclick="flipCamera()" title="Juyar Camera">
        <i class="fa fa-sync"></i>
    </button>
    <?php endif; ?>
    <button class="ctrl-btn btn-speaker" id="btn-speaker" onclick="toggleSpeaker()" title="Speaker">
        <i class="fa fa-volume-up"></i>
    </button>
    <button class="ctrl-btn btn-end" onclick="endCall()" title="Ƙare Kira">
        <i class="fa fa-phone-slash"></i>
    </button>
</div>

<script>
const MY_ID     = <?=$my_id?>;
const CALLEE_ID = <?=$callee_id?>;
const CALL_TYPE = '<?=$call_type?>';
const IS_VIDEO  = <?=$is_video?'true':'false'?>;
const IS_CALLER = CALLEE_ID > 0; // true = we are the caller

let callId      = 0;
let pc          = null;  // RTCPeerConnection
let localStream = null;
let callActive  = false;
let callSeconds = 0;
let callTimerInt= null;
let ringTimeout = null;
let incomingCallId = 0;
let incomingCountdown = null;
let muted       = false;
let camOff      = false;
let facingMode  = 'user';

// STUN servers (free public)
const ICE_SERVERS = {
    iceServers: [
        {urls:'stun:stun.l.google.com:19302'},
        {urls:'stun:stun1.l.google.com:19302'},
    ]
};

// ─────────────────────────────────────────
// INIT
// ─────────────────────────────────────────
window.addEventListener('load', async () => {
    if (IS_CALLER) {
        await initAsCaller();
    } else {
        // No callee_id — we are waiting/polling for incoming calls
        pollIncoming();
    }
});

// ─────────────────────────────────────────
// CALLER SIDE
// ─────────────────────────────────────────
async function initAsCaller() {
    document.getElementById('call-status').textContent = 'Ana samar da kira...';
    // Get local media
    localStream = await getMedia();
    if (IS_VIDEO && localStream) {
        document.getElementById('local-video').srcObject = localStream;
    }
    // Register call in DB
    const fd = new FormData();
    fd.append('action','initiate'); fd.append('to',CALLEE_ID); fd.append('type',CALL_TYPE);
    const r = await fetch('call.php',{method:'POST',body:fd});
    const d = await r.json();
    callId = d.call_id;

    // Create peer connection
    pc = new RTCPeerConnection(ICE_SERVERS);
    if (localStream) localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

    pc.ontrack = e => {
        const rv = document.getElementById('remote-video');
        if (IS_VIDEO) { rv.srcObject = e.streams[0]; rv.style.display='block'; }
        else {
            // Voice: play audio
            const audio = new Audio();
            audio.srcObject = e.streams[0];
            audio.play();
        }
        onCallConnected();
    };

    pc.onicecandidate = e => {
        if (e.candidate) sendICE(JSON.stringify(e.candidate),'caller');
    };

    // Create offer
    const offer = await pc.createOffer({offerToReceiveAudio:true, offerToReceiveVideo:IS_VIDEO});
    await pc.setLocalDescription(offer);
    const fd2 = new FormData();
    fd2.append('action','offer'); fd2.append('call_id',callId); fd2.append('sdp',JSON.stringify(offer));
    await fetch('call.php',{method:'POST',body:fd2});

    document.getElementById('call-status').textContent = 'Ana buga kira...';

    // 10-second ring timeout → missed
    ringTimeout = setTimeout(() => {
        if (!callActive) {
            markMissed();
            showEnded('☎️ Kira bai amsa ba', 'Bai daga ba — Kira ya ƙare');
        }
    }, 10000);

    // Poll for answer
    pollForAnswer();
}

async function pollForAnswer() {
    if (callActive) return;
    const fd = new FormData();
    fd.append('action','poll'); fd.append('call_id',callId);
    const r = await fetch('call.php',{method:'POST',body:fd});
    const d = await r.json();

    if (d.status === 'active' && d.answer_sdp) {
        clearTimeout(ringTimeout);
        const answer = JSON.parse(d.answer_sdp);
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
        // Apply callee ICE if available
        if (d.callee_ice) {
            try { await pc.addIceCandidate(new RTCIceCandidate(JSON.parse(d.callee_ice))); } catch(e){}
        }
        onCallConnected();
    } else if (d.status === 'declined') {
        clearTimeout(ringTimeout);
        showEnded('❌ Kira an ƙi', 'Ya ƙi kiran — zai iya kasancewa yana da aiki');
    } else if (d.status === 'missed' || d.status === 'ended') {
        clearTimeout(ringTimeout);
        showEnded('☎️ Kira ya ƙare', '');
    } else if (d.status === 'ringing') {
        setTimeout(pollForAnswer, 1500);
    }
}

// ─────────────────────────────────────────
// CALLEE SIDE — Incoming call polling
// ─────────────────────────────────────────
async function pollIncoming() {
    const fd = new FormData();
    fd.append('action','check_incoming');
    const r  = await fetch('call.php',{method:'POST',body:fd});
    const d  = await r.json();

    if (!d.none) {
        showIncoming(d);
    } else {
        setTimeout(pollIncoming, 2000);
    }
}

function showIncoming(call) {
    incomingCallId = call.id;
    const screen = document.getElementById('incoming-screen');
    screen.classList.add('show');
    document.getElementById('inc-avatar').src = call.profile_pic ? 'uploads/' + call.profile_pic : 'assets/default.png';
    document.getElementById('inc-name').textContent = call.username;
    document.getElementById('inc-label').textContent = call.call_type === 'video' ? '📹 Video Call' : '📞 Voice Call';

    // 10-second countdown to auto-dismiss
    let sec = 10;
    document.getElementById('inc-timer').textContent = sec;
    incomingCountdown = setInterval(() => {
        sec--;
        document.getElementById('inc-timer').textContent = sec;
        if (sec <= 0) {
            clearInterval(incomingCountdown);
            markMissedIncoming();
            screen.classList.remove('show');
            showEnded('☎️ Kira ya wuce', 'Baka daga ba');
        }
    }, 1000);
}

async function answerCall() {
    clearInterval(incomingCountdown);
    document.getElementById('incoming-screen').classList.remove('show');
    document.getElementById('call-status').textContent = 'Ana haɗa kira...';
    callId = incomingCallId;

    // Get local media
    localStream = await getMedia();
    if (IS_VIDEO && localStream) document.getElementById('local-video').srcObject = localStream;

    pc = new RTCPeerConnection(ICE_SERVERS);
    if (localStream) localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

    pc.ontrack = e => {
        const rv = document.getElementById('remote-video');
        if (IS_VIDEO) { rv.srcObject = e.streams[0]; rv.style.display='block'; }
        else { const a=new Audio(); a.srcObject=e.streams[0]; a.play(); }
        onCallConnected();
    };

    pc.onicecandidate = e => {
        if (e.candidate) sendICE(JSON.stringify(e.candidate),'callee');
    };

    // Get offer from DB
    const fd  = new FormData(); fd.append('action','poll'); fd.append('call_id',callId);
    const r   = await fetch('call.php',{method:'POST',body:fd});
    const d   = await r.json();
    if (!d.offer_sdp) { showEnded('❌ Kuskure','Ba a samu offer ba'); return; }

    await pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(d.offer_sdp)));
    if (d.caller_ice) {
        try { await pc.addIceCandidate(new RTCIceCandidate(JSON.parse(d.caller_ice))); } catch(e){}
    }

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    const fd2 = new FormData(); fd2.append('action','answer');
    fd2.append('call_id',callId); fd2.append('sdp',JSON.stringify(answer));
    await fetch('call.php',{method:'POST',body:fd2});
    onCallConnected();
}

async function declineCall() {
    clearInterval(incomingCountdown);
    document.getElementById('incoming-screen').classList.remove('show');
    const fd = new FormData(); fd.append('action','decline'); fd.append('call_id',incomingCallId);
    await fetch('call.php',{method:'POST',body:fd});
    showEnded('❌ Kira an ƙi','Ka ƙi kiran');
}

async function markMissedIncoming() {
    const fd = new FormData(); fd.append('action','missed'); fd.append('call_id',incomingCallId);
    await fetch('call.php',{method:'POST',body:fd});
}

// ─────────────────────────────────────────
// CONNECTED
// ─────────────────────────────────────────
function onCallConnected() {
    if (callActive) return;
    callActive = true;
    document.getElementById('call-status').textContent = 'Kira na gudana';
    document.getElementById('call-timer').style.display = 'block';
    // Animate ring waves (stop pulsing fast when connected)
    document.querySelectorAll('.wave-ring').forEach(w => w.style.animationDuration='4s');
    // Start timer
    callTimerInt = setInterval(() => {
        callSeconds++;
        const m = Math.floor(callSeconds/60);
        const s = callSeconds % 60;
        document.getElementById('call-timer').textContent = m + ':' + String(s).padStart(2,'0');
    }, 1000);
}

// ─────────────────────────────────────────
// END CALL
// ─────────────────────────────────────────
async function endCall() {
    clearTimeout(ringTimeout);
    clearInterval(callTimerInt);
    if (localStream) localStream.getTracks().forEach(t => t.stop());
    if (pc) pc.close();
    if (callId) {
        const fd = new FormData(); fd.append('action','end'); fd.append('call_id',callId);
        await fetch('call.php',{method:'POST',body:fd});
    }
    callActive = false;
    const dur = callSeconds > 0 ? formatDuration(callSeconds) : '';
    showEnded('📞 Kira ya ƙare', dur ? 'Tsawon lokaci: ' + dur : 'Kira ya ƙare');
}

async function markMissed() {
    if (callId) {
        const fd = new FormData(); fd.append('action','missed'); fd.append('call_id',callId);
        await fetch('call.php',{method:'POST',body:fd});
    }
}

function showEnded(title, sub) {
    const ov = document.getElementById('status-overlay');
    document.getElementById('so-icon').textContent = '📵';
    document.getElementById('so-text').textContent = title;
    document.getElementById('so-sub').textContent  = sub;
    ov.classList.add('show');
    document.getElementById('call-controls').style.display = 'none';
    setTimeout(() => goBack(), 5000);
}

function goBack() {
    history.back();
}

// ─────────────────────────────────────────
// CONTROLS
// ─────────────────────────────────────────
function toggleMute() {
    if (!localStream) return;
    muted = !muted;
    localStream.getAudioTracks().forEach(t => t.enabled = !muted);
    const btn = document.getElementById('btn-mute');
    btn.classList.toggle('active', muted);
    btn.innerHTML = muted ? '<i class="fa fa-microphone-slash"></i>' : '<i class="fa fa-microphone"></i>';
}

function toggleCam() {
    if (!localStream) return;
    camOff = !camOff;
    localStream.getVideoTracks().forEach(t => t.enabled = !camOff);
    const btn = document.getElementById('btn-cam');
    btn.classList.toggle('active', camOff);
    btn.innerHTML = camOff ? '<i class="fa fa-video-slash"></i>' : '<i class="fa fa-video"></i>';
}

async function flipCamera() {
    facingMode = facingMode === 'user' ? 'environment' : 'user';
    if (!localStream) return;
    localStream.getVideoTracks().forEach(t => t.stop());
    const newStream = await navigator.mediaDevices.getUserMedia({
        video:{facingMode}, audio:true
    });
    const newVideoTrack = newStream.getVideoTracks()[0];
    document.getElementById('local-video').srcObject = newStream;
    if (pc) {
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        if (sender) sender.replaceTrack(newVideoTrack);
    }
    localStream = newStream;
}

function toggleSpeaker() {
    const btn = document.getElementById('btn-speaker');
    btn.classList.toggle('active');
    // On mobile, toggling speaker is handled by the OS; this is visual feedback
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────
async function getMedia() {
    try {
        if (IS_VIDEO) {
            return await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}, audio:true});
        } else {
            return await navigator.mediaDevices.getUserMedia({audio:true});
        }
    } catch(e) {
        document.getElementById('call-status').textContent = '❌ Ba a samu damar camera/mic ba';
        return null;
    }
}

async function sendICE(ice, role) {
    if (!callId) return;
    const fd = new FormData();
    fd.append('action','ice'); fd.append('call_id',callId);
    fd.append('ice',ice); fd.append('role',role);
    await fetch('call.php',{method:'POST',body:fd});
}

function formatDuration(secs) {
    const m = Math.floor(secs/60);
    const s = secs % 60;
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

// Prevent page unload without ending call
window.addEventListener('beforeunload', () => {
    if (callActive && callId) {
        navigator.sendBeacon('call.php', new URLSearchParams({action:'end',call_id:callId}));
    }
});
</script>
</body>
</html>
