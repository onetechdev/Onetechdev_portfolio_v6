<?php
require_once '../inc/config.php';

$admin = $conn->query("SELECT * FROM users WHERE id={$_SESSION['user_id']}")->fetch_assoc();
if (!isLoggedIn() || $admin['id'] !== 1) {
    redirect('../index.php');
}

$successMsg = '';
$errorMsg   = '';

// ── HANDLE: Add Portfolio Project ─────────────────────────────────────
if (isset($_POST['add_project'])) {
    $title    = clean($conn, $_POST['ptitle'] ?? '');
    $desc     = clean($conn, $_POST['pdesc'] ?? '');
    $tech     = clean($conn, $_POST['ptech'] ?? '');
    $link     = clean($conn, $_POST['plink'] ?? '');
    $category = clean($conn, $_POST['pcategory'] ?? '');
    $featured = isset($_POST['pfeatured']) ? 1 : 0;
    $img_url  = '';

    if (isset($_FILES['pimage']) && $_FILES['pimage']['error'] === 0) {
        $ext  = strtolower(pathinfo($_FILES['pimage']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];
        if (in_array($ext, $allowed)) {
            $fn = 'proj_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['pimage']['tmp_name'], '../uploads/' . $fn);
            $img_url = 'uploads/' . $fn;
        }
    }

    $conn->query("INSERT INTO portfolio_projects (title, description, tech_stack, project_url, category, image_url, is_featured)
                  VALUES ('$title','$desc','$tech','$link','$category','$img_url',$featured)");
    $successMsg = "✅ An kara project: $title";
}

// ── HANDLE: Edit Portfolio Project ────────────────────────────────────
if (isset($_POST['edit_project'])) {
    $pid      = (int)$_POST['pid'];
    $title    = clean($conn, $_POST['ptitle'] ?? '');
    $desc     = clean($conn, $_POST['pdesc'] ?? '');
    $tech     = clean($conn, $_POST['ptech'] ?? '');
    $link     = clean($conn, $_POST['plink'] ?? '');
    $category = clean($conn, $_POST['pcategory'] ?? '');
    $featured = isset($_POST['pfeatured']) ? 1 : 0;

    $img_update = '';
    if (isset($_FILES['pimage']) && $_FILES['pimage']['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES['pimage']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $fn = 'proj_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['pimage']['tmp_name'], '../uploads/' . $fn);
            $img_update = ", image_url='uploads/$fn'";
        }
    }

    $conn->query("UPDATE portfolio_projects SET title='$title', description='$desc', tech_stack='$tech',
                  project_url='$link', category='$category', is_featured=$featured $img_update WHERE id=$pid");
    $successMsg = "✅ An sabunta project";
}

// ── HANDLE: Delete Portfolio Project ──────────────────────────────────
if (isset($_POST['delete_project'])) {
    $pid = (int)$_POST['pid'];
    $conn->query("DELETE FROM portfolio_projects WHERE id=$pid");
    $successMsg = "🗑️ An share project";
}

// ── HANDLE: Delete Post/Video ──────────────────────────────────────────
if (isset($_POST['delete_post'])) {
    $pid = (int)$_POST['post_id'];
    $conn->query("DELETE FROM posts WHERE id=$pid");
    $successMsg = "🗑️ An share post";
}

// ── HANDLE: Ban/Unban User ─────────────────────────────────────────────
if (isset($_POST['ban_user'])) {
    $uid     = (int)$_POST['ban_uid'];
    $is_ban  = (int)$_POST['ban_val'];
    $conn->query("UPDATE users SET is_banned=$is_ban WHERE id=$uid AND id!=1");
    $successMsg = $is_ban ? "🚫 An hana user" : "✅ An sake ba user damar shiga";
}

// ── HANDLE: Verify User ────────────────────────────────────────────────
if (isset($_POST['verify_user'])) {
    $uid = (int)$_POST['verify_uid'];
    $val = (int)$_POST['verify_val'];
    $conn->query("UPDATE users SET is_verified=$val WHERE id=$uid");
    $successMsg = $val ? "✅ User ya sami tabbatarwa" : "❌ An cire tabbatarwa";
}

// ── HANDLE: Change User Role ───────────────────────────────────────────
if (isset($_POST['change_role'])) {
    $uid  = (int)$_POST['role_uid'];
    $role = clean($conn, $_POST['new_role'] ?? '');
    $allowed = ['developer','programmer','backend_dev','frontend_dev','server_security'];
    if (in_array($role, $allowed)) {
        $conn->query("UPDATE users SET role='$role' WHERE id=$uid AND id!=1");
        $successMsg = "✅ An canja matsayin user";
    }
}

// ── HANDLE: Delete User ────────────────────────────────────────────────
if (isset($_POST['delete_user'])) {
    $uid = (int)$_POST['del_id'];
    if ($uid !== 1) {
        $conn->query("DELETE FROM users WHERE id=$uid");
        $successMsg = "🗑️ An share user";
    }
}

// ── HANDLE: Broadcast Notification ────────────────────────────────────
if (isset($_POST['send_broadcast'])) {
    $msg    = clean($conn, $_POST['broadcast_msg'] ?? '');
    $target = $_POST['target'] ?? 'all';
    if (!empty($msg)) {
        $where  = $target === 'all' ? "id != {$admin['id']}" : "role='" . clean($conn,$target) . "' AND id!={$admin['id']}";
        $ulist  = $conn->query("SELECT id FROM users WHERE $where");
        $sent   = 0;
        while ($u = $ulist->fetch_assoc()) {
            $conn->query("INSERT INTO notifications (user_id, from_user_id, type, message)
                          VALUES ({$u['id']}, {$admin['id']}, 'message', '$msg')");
            $sent++;
        }
        $successMsg = "✅ An aika saƙo ga $sent user(s)";
    }
}

// ── HANDLE: Edit Site Settings (About/Contact on index.php) ────────────
if (isset($_POST['save_settings'])) {
    $bio      = clean($conn, $_POST['admin_bio'] ?? '');
    $skills   = clean($conn, $_POST['admin_skills'] ?? '');
    $whatsapp = clean($conn, $_POST['admin_whatsapp'] ?? '');
    $github   = clean($conn, $_POST['admin_github'] ?? '');
    $email    = clean($conn, $_POST['admin_email'] ?? '');

    // Upsert each setting
    foreach ([
        'admin_bio'       => $bio,
        'admin_skills'    => $skills,
        'admin_whatsapp'  => $whatsapp,
        'admin_github'    => $github,
        'admin_email'     => $email,
    ] as $key => $val) {
        $conn->query("INSERT INTO site_settings (`key`,`value`) VALUES ('$key','$val')
                      ON DUPLICATE KEY UPDATE `value`='$val'");
    }
    $successMsg = "✅ An adana saitunan shafin";
}

// ── STATS ──────────────────────────────────────────────────────────────
$totalUsers    = $conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$totalPosts    = $conn->query("SELECT COUNT(*) c FROM posts WHERE post_type='post'")->fetch_assoc()['c'];
$totalVideos   = $conn->query("SELECT COUNT(*) c FROM posts WHERE media_type='video' AND post_type='post'")->fetch_assoc()['c'];
$totalMessages = $conn->query("SELECT COUNT(*) c FROM messages")->fetch_assoc()['c'];
$totalCalls    = $conn->query("SELECT COUNT(*) c FROM calls")->fetch_assoc()['c'] ?? 0;
$newToday      = $conn->query("SELECT COUNT(*) c FROM users WHERE DATE(created_at)=CURDATE()")->fetch_assoc()['c'];
$onlineNow     = $conn->query("SELECT COUNT(*) c FROM users WHERE is_online=1")->fetch_assoc()['c'] ?? 0;

// Check if portfolio_projects table exists, create if not
$conn->query("CREATE TABLE IF NOT EXISTS portfolio_projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    tech_stack VARCHAR(255),
    project_url VARCHAR(500),
    category VARCHAR(50) DEFAULT 'web',
    image_url VARCHAR(255),
    is_featured TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Check if site_settings table exists
$conn->query("CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) UNIQUE NOT NULL,
    `value` TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Add is_banned column if missing
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned TINYINT(1) DEFAULT 0");

// Load data
$allUsers    = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
$allPosts    = $conn->query("SELECT p.*, u.username, u.profile_pic FROM posts p JOIN users u ON p.user_id=u.id WHERE post_type='post' ORDER BY p.created_at DESC LIMIT 100");
$allProjects = $conn->query("SELECT * FROM portfolio_projects ORDER BY is_featured DESC, created_at DESC");
$roleStats   = $conn->query("SELECT role, COUNT(*) c FROM users GROUP BY role");

// Site settings
$settingsRaw = $conn->query("SELECT `key`,`value` FROM site_settings");
$settings    = [];
if ($settingsRaw) while ($s = $settingsRaw->fetch_assoc()) $settings[$s['key']] = $s['value'];

// 7-day user signups chart
$signupData  = $conn->query("SELECT DATE(created_at) d, COUNT(*) c FROM users WHERE created_at >= DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY d");
$chartLabels = []; $chartVals = [];
if ($signupData) while ($r = $signupData->fetch_assoc()) { $chartLabels[] = $r['d']; $chartVals[] = $r['c']; }
?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel — Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI',sans-serif;background:#0a0a0a;color:#fff;display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:230px;background:#111;border-right:1px solid #1e1e1e;display:flex;flex-direction:column;position:fixed;top:0;left:0;height:100vh;z-index:100;transition:0.3s;}
.sidebar-logo{padding:22px 20px;border-bottom:1px solid #1e1e1e;font-size:1rem;font-weight:700;color:#00d4ff;}
.sidebar-logo i{margin-right:8px;}
.sidebar nav{flex:1;padding:15px 0;overflow-y:auto;}
.sidebar nav a{display:flex;align-items:center;gap:10px;padding:11px 20px;color:#888;text-decoration:none;font-size:0.88rem;transition:0.2s;border-left:3px solid transparent;}
.sidebar nav a:hover,.sidebar nav a.active{color:#00d4ff;border-left-color:#00d4ff;background:rgba(0,212,255,0.05);}
.sidebar nav a i{width:16px;text-align:center;}
.sidebar-sep{margin:8px 20px;border:none;border-top:1px solid #1e1e1e;}
.sidebar-footer{padding:15px 20px;border-top:1px solid #1e1e1e;}
.sidebar-footer a{color:#666;text-decoration:none;font-size:0.85rem;display:flex;align-items:center;gap:8px;}
.sidebar-footer a:hover{color:#ff4444;}

/* MAIN */
.main{margin-left:230px;flex:1;min-height:100vh;padding:30px;}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;padding-bottom:18px;border-bottom:1px solid #1e1e1e;}
.topbar h1{font-size:1.3rem;color:#fff;}
.topbar span{color:#555;font-size:0.82rem;}
.badge-online{background:#00ff88;width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:5px;}

/* ALERTS */
.alert{padding:12px 16px;border-radius:8px;margin-bottom:20px;font-size:0.88rem;}
.alert-success{background:rgba(0,255,136,0.1);border:1px solid rgba(0,255,136,0.3);color:#00ff88;}
.alert-error{background:rgba(255,68,68,0.1);border:1px solid rgba(255,68,68,0.3);color:#ff4444;}

/* SECTIONS */
.section{background:#111;border:1px solid #1e1e1e;border-radius:14px;padding:24px;margin-bottom:24px;display:none;}
.section.active{display:block;}
.section-title{display:flex;align-items:center;gap:10px;margin-bottom:22px;padding-bottom:14px;border-bottom:1px solid #1e1e1e;}
.section-title h2{font-size:1rem;color:#00d4ff;}

/* STATS GRID */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:24px;}
.stat-card{background:#151515;border:1px solid #1e1e1e;border-radius:12px;padding:18px;transition:0.3s;}
.stat-card:hover{border-color:#00d4ff;}
.stat-icon{font-size:1.6rem;margin-bottom:8px;}
.stat-val{font-size:1.9rem;font-weight:800;color:#00d4ff;}
.stat-lbl{color:#555;font-size:0.75rem;margin-top:3px;}

/* CHART */
.chart-wrap{background:#151515;border:1px solid #1e1e1e;border-radius:12px;padding:18px;margin-bottom:24px;}
.chart-wrap h4{color:#aaa;font-size:0.85rem;margin-bottom:14px;}

/* TABLES */
.tbl{width:100%;border-collapse:collapse;font-size:0.83rem;}
.tbl th{padding:10px 14px;text-align:left;color:#555;border-bottom:1px solid #1e1e1e;font-weight:500;white-space:nowrap;}
.tbl td{padding:11px 14px;border-bottom:1px solid #111;vertical-align:middle;}
.tbl tr:hover td{background:rgba(255,255,255,0.02);}
.tbl img{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid #222;}
.tbl-wrap{overflow-x:auto;}

/* BADGE */
.badge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:0.72rem;font-weight:600;}
.badge-dev{background:#1a3a5c;color:#00d4ff;}
.badge-prog{background:#1a3a1a;color:#00ff88;}
.badge-back{background:#3a1a1a;color:#ff6b6b;}
.badge-front{background:#3a3a1a;color:#ffd700;}
.badge-sec{background:#2a1a3a;color:#bf7fff;}
.badge-verified{background:rgba(0,212,255,0.15);color:#00d4ff;}
.badge-banned{background:rgba(255,68,68,0.15);color:#ff4444;}
.badge-featured{background:rgba(255,215,0,0.15);color:#ffd700;}

/* BUTTONS */
.btn{padding:7px 14px;border-radius:7px;border:none;cursor:pointer;font-size:0.8rem;font-weight:600;transition:0.2s;display:inline-flex;align-items:center;gap:5px;}
.btn-cyan{background:#00d4ff;color:#000;}
.btn-cyan:hover{background:#00b8d9;}
.btn-red{background:rgba(255,68,68,0.15);color:#ff4444;border:1px solid rgba(255,68,68,0.3);}
.btn-red:hover{background:#ff4444;color:#fff;}
.btn-green{background:rgba(0,255,136,0.15);color:#00ff88;border:1px solid rgba(0,255,136,0.3);}
.btn-green:hover{background:#00ff88;color:#000;}
.btn-yellow{background:rgba(255,215,0,0.15);color:#ffd700;border:1px solid rgba(255,215,0,0.3);}
.btn-yellow:hover{background:#ffd700;color:#000;}
.btn-grey{background:#1e1e1e;color:#aaa;border:1px solid #2a2a2a;}
.btn-grey:hover{border-color:#555;color:#fff;}
.btn-sm{padding:4px 10px;font-size:0.75rem;}

/* FORMS */
.aform{display:flex;flex-direction:column;gap:12px;}
.aform input,.aform textarea,.aform select{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:8px;color:#fff;padding:10px 14px;font-size:0.87rem;width:100%;transition:0.2s;}
.aform input:focus,.aform textarea:focus,.aform select:focus{border-color:#00d4ff;outline:none;}
.aform label.chk{display:flex;align-items:center;gap:8px;color:#aaa;font-size:0.85rem;cursor:pointer;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.form-row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;}
.flbl{color:#888;font-size:0.78rem;margin-bottom:2px;}
.section-tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.section-tab{padding:7px 16px;border-radius:6px;border:1px solid #2a2a2a;background:#151515;color:#888;cursor:pointer;font-size:0.82rem;transition:0.2s;}
.section-tab.active{background:#00d4ff;color:#000;border-color:#00d4ff;}

/* PROJECT CARDS */
.proj-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;}
.proj-card{background:#151515;border:1px solid #1e1e1e;border-radius:12px;overflow:hidden;transition:0.2s;}
.proj-card:hover{border-color:#333;}
.proj-card img{width:100%;height:140px;object-fit:cover;}
.proj-card-noimg{width:100%;height:140px;background:linear-gradient(135deg,#1a1a2e,#0d1117);display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:#333;}
.proj-body{padding:14px;}
.proj-title{font-weight:700;font-size:0.93rem;margin-bottom:4px;}
.proj-cat{color:#00d4ff;font-size:0.75rem;margin-bottom:6px;}
.proj-desc{color:#666;font-size:0.8rem;line-height:1.5;margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.proj-tech{color:#888;font-size:0.75rem;margin-bottom:10px;}
.proj-actions{display:flex;gap:6px;}

/* SEARCH */
.search-bar{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:20px;padding:9px 16px;color:#fff;width:100%;font-size:0.85rem;margin-bottom:16px;}
.search-bar:focus{border-color:#00d4ff;outline:none;}

/* MODAL */
.modal-overlay{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:999;justify-content:center;align-items:flex-start;padding:30px 15px;overflow-y:auto;}
.modal-overlay.open{display:flex;}
.modal-box{background:#111;border:1px solid #2a2a2a;border-radius:16px;padding:28px;width:100%;max-width:560px;position:relative;margin:auto;}
.modal-close{position:absolute;top:14px;right:16px;background:none;border:none;color:#666;font-size:1.3rem;cursor:pointer;}
.modal-close:hover{color:#ff4444;}
.modal-title{font-size:1rem;color:#00d4ff;margin-bottom:20px;display:flex;align-items:center;gap:8px;}

/* POST CARDS */
.post-item{display:flex;gap:14px;padding:14px 0;border-bottom:1px solid #1a1a1a;align-items:flex-start;}
.post-item:last-child{border:none;}
.post-thumb{width:70px;height:70px;border-radius:8px;object-fit:cover;flex-shrink:0;}
.post-thumb-none{width:70px;height:70px;border-radius:8px;background:#1a1a1a;display:flex;align-items:center;justify-content:center;color:#333;font-size:1.5rem;flex-shrink:0;}
.post-info{flex:1;min-width:0;}
.post-user{font-size:0.82rem;color:#aaa;margin-bottom:3px;}
.post-content{font-size:0.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:5px;}
.post-meta{font-size:0.75rem;color:#555;display:flex;gap:12px;}

/* RESPONSIVE */
@media(max-width:768px){
    .sidebar{transform:translateX(-100%);}
    .sidebar.open{transform:translateX(0);}
    .main{margin-left:0;}
    .form-row,.form-row3{grid-template-columns:1fr;}
    .mob-menu-btn{display:block !important;}
}
.mob-menu-btn{display:none;position:fixed;top:15px;left:15px;z-index:200;background:#00d4ff;color:#000;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;font-size:1rem;}

/* SETTINGS */
.settings-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:600px){.settings-row{grid-template-columns:1fr;}}
</style>
</head>
<body>

<button class="mob-menu-btn" id="mob-btn" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-logo"><i class="fa fa-shield-halved"></i> Admin Panel</div>
    <nav>
        <a href="#" class="active" onclick="showSection('dashboard',this)"><i class="fa fa-chart-line"></i> Dashboard</a>
        <a href="#" onclick="showSection('portfolio',this)"><i class="fa fa-briefcase"></i> Portfolio Projects</a>
        <a href="#" onclick="showSection('posts',this)"><i class="fa fa-newspaper"></i> Posts & Videos</a>
        <a href="#" onclick="showSection('users',this)"><i class="fa fa-users"></i> Manage Users</a>
        <hr class="sidebar-sep">
        <a href="#" onclick="showSection('broadcast',this)"><i class="fa fa-bullhorn"></i> Broadcast Saƙo</a>
        <a href="#" onclick="showSection('settings',this)"><i class="fa fa-gear"></i> Site Settings</a>
        <hr class="sidebar-sep">
        <a href="../home.php" target="_blank"><i class="fa fa-eye"></i> View Site</a>
    </nav>
    <div class="sidebar-footer">
        <a href="../logout.php"><i class="fa fa-sign-out-alt"></i> Logout (<?= $admin['username'] ?>)</a>
    </div>
</div>

<!-- MAIN -->
<div class="main">
    <div class="topbar">
        <h1><i class="fa fa-shield-halved" style="color:#00d4ff"></i> Onetech Dev Admin</h1>
        <span><span class="badge-online"></span><?= $onlineNow ?> online &nbsp;|&nbsp; <?= date('d M Y, H:i') ?></span>
    </div>

    <?php if ($successMsg): ?>
        <div class="alert alert-success"><?= $successMsg ?></div>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
        <div class="alert alert-error"><?= $errorMsg ?></div>
    <?php endif; ?>

    <!-- ══ DASHBOARD ══════════════════════════════════════════════════ -->
    <div class="section active" id="sec-dashboard">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-val"><?= $totalUsers ?></div>
                <div class="stat-lbl">Duk Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-val"><?= $totalPosts ?></div>
                <div class="stat-lbl">Duk Posts</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🎬</div>
                <div class="stat-val"><?= $totalVideos ?></div>
                <div class="stat-lbl">Videos</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💬</div>
                <div class="stat-val"><?= $totalMessages ?></div>
                <div class="stat-lbl">Messages</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📞</div>
                <div class="stat-val"><?= $totalCalls ?></div>
                <div class="stat-lbl">Calls</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🆕</div>
                <div class="stat-val"><?= $newToday ?></div>
                <div class="stat-lbl">Sabon Yau</div>
            </div>
        </div>

        <!-- 7-Day Signup Chart -->
        <div class="chart-wrap">
            <h4><i class="fa fa-chart-bar"></i> Users da suka shiga — 7 Ranaku</h4>
            <canvas id="signupChart" height="80"></canvas>
        </div>

        <!-- Role breakdown -->
        <div class="section-title"><h2><i class="fa fa-pie-chart"></i> Users ta Role</h2></div>
        <div class="stats-grid">
        <?php
        $roleColors = ['developer'=>'#00d4ff','programmer'=>'#00ff88','backend_dev'=>'#ff6b6b','frontend_dev'=>'#ffd700','server_security'=>'#bf7fff'];
        $roleStats->data_seek(0);
        while ($r = $roleStats->fetch_assoc()):
            $col = $roleColors[$r['role']] ?? '#aaa';
        ?>
            <div class="stat-card" style="border-left:3px solid <?=$col?>;">
                <div class="stat-val" style="color:<?=$col?>;font-size:1.4rem;"><?=$r['c']?></div>
                <div class="stat-lbl"><?= str_replace('_',' ', ucfirst($r['role'])) ?></div>
            </div>
        <?php endwhile; ?>
        </div>
    </div>

    <!-- ══ PORTFOLIO PROJECTS ════════════════════════════════════════ -->
    <div class="section" id="sec-portfolio">
        <div class="section-title">
            <h2><i class="fa fa-briefcase"></i> Portfolio Projects</h2>
            <button class="btn btn-cyan" style="margin-left:auto" onclick="openModal('modal-add-proj')"><i class="fa fa-plus"></i> Kara Project</button>
        </div>

        <?php if ($allProjects->num_rows === 0): ?>
            <p style="color:#555;text-align:center;padding:40px;">Ba a sami wani project ba tukuna. Ka kara na farko!</p>
        <?php else: ?>
        <div class="proj-grid">
        <?php $allProjects->data_seek(0); while ($p = $allProjects->fetch_assoc()): ?>
            <div class="proj-card">
                <?php if ($p['image_url']): ?>
                    <img src="../<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
                <?php else: ?>
                    <div class="proj-card-noimg">🖥️</div>
                <?php endif; ?>
                <div class="proj-body">
                    <?php if ($p['is_featured']): ?><span class="badge badge-featured">⭐ Featured</span><br><br><?php endif; ?>
                    <div class="proj-title"><?= htmlspecialchars($p['title']) ?></div>
                    <div class="proj-cat"><?= htmlspecialchars($p['category']) ?></div>
                    <div class="proj-desc"><?= htmlspecialchars($p['description']) ?></div>
                    <div class="proj-tech"><i class="fa fa-code" style="color:#555"></i> <?= htmlspecialchars($p['tech_stack']) ?></div>
                    <div class="proj-actions">
                        <button class="btn btn-grey btn-sm" onclick="editProject(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="fa fa-edit"></i> Gyara</button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Share project?')">
                            <input type="hidden" name="delete_project" value="1">
                            <input type="hidden" name="pid" value="<?=$p['id']?>">
                            <button class="btn btn-red btn-sm"><i class="fa fa-trash"></i></button>
                        </form>
                        <?php if ($p['project_url']): ?>
                        <a href="<?= htmlspecialchars($p['project_url']) ?>" target="_blank" class="btn btn-green btn-sm"><i class="fa fa-external-link"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- ══ POSTS & VIDEOS ════════════════════════════════════════════ -->
    <div class="section" id="sec-posts">
        <div class="section-title"><h2><i class="fa fa-newspaper"></i> Posts & Videos</h2></div>
        <div class="section-tabs">
            <span class="section-tab active" onclick="filterPosts('all',this)">Duk</span>
            <span class="section-tab" onclick="filterPosts('image',this)">Hotuna</span>
            <span class="section-tab" onclick="filterPosts('video',this)">Videos</span>
            <span class="section-tab" onclick="filterPosts('none',this)">Text Posts</span>
        </div>
        <input type="text" class="search-bar" placeholder="🔍 Nema post ko username..." id="post-search" oninput="searchPosts()">
        <div id="posts-list">
        <?php $allPosts->data_seek(0); while ($p = $allPosts->fetch_assoc()): ?>
        <div class="post-item" data-type="<?=$p['media_type']?>" data-text="<?= strtolower(htmlspecialchars($p['username'].' '.$p['content'])) ?>">
            <?php if ($p['media_url'] && in_array($p['media_type'],['image','video'])): ?>
                <img class="post-thumb" src="../<?= htmlspecialchars($p['media_url']) ?>" onerror="this.style.display='none'">
            <?php else: ?>
                <div class="post-thumb-none"><i class="fa fa-<?= $p['media_type']==='video'?'video':'align-left' ?>"></i></div>
            <?php endif; ?>
            <div class="post-info">
                <div class="post-user">
                    @<?= htmlspecialchars($p['username']) ?> &nbsp;·&nbsp; <?= date('d M Y', strtotime($p['created_at'])) ?>
                </div>
                <div class="post-content"><?= htmlspecialchars($p['content'] ?: '(media only)') ?></div>
                <div class="post-meta">
                    <span><i class="fa fa-heart" style="color:#ff4444"></i> <?= $p['likes_count'] ?></span>
                    <span><i class="fa fa-comment" style="color:#00d4ff"></i> <?= $p['comments_count'] ?></span>
                    <span><i class="fa fa-eye" style="color:#888"></i> <?= $p['view_count'] ?? 0 ?></span>
                    <span class="badge badge-dev"><?= $p['media_type'] ?></span>
                </div>
            </div>
            <form method="POST" style="flex-shrink:0" onsubmit="return confirm('Share post?')">
                <input type="hidden" name="delete_post" value="1">
                <input type="hidden" name="post_id" value="<?=$p['id']?>">
                <button class="btn btn-red btn-sm"><i class="fa fa-trash"></i></button>
            </form>
        </div>
        <?php endwhile; ?>
        </div>
    </div>

    <!-- ══ MANAGE USERS ══════════════════════════════════════════════ -->
    <div class="section" id="sec-users">
        <div class="section-title"><h2><i class="fa fa-users"></i> Manage Users (<?= $totalUsers ?>)</h2></div>
        <input type="text" class="search-bar" placeholder="🔍 Nema user, email, ko role..." id="user-search" oninput="searchUsers()">
        <div class="tbl-wrap">
        <table class="tbl">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th>Ayyuka</th>
                </tr>
            </thead>
            <tbody id="users-tbody">
            <?php $allUsers->data_seek(0); while ($u = $allUsers->fetch_assoc()): ?>
            <tr data-text="<?= strtolower(htmlspecialchars($u['username'].' '.$u['email'].' '.$u['role'])) ?>">
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <img src="../<?= htmlspecialchars($u['profile_pic'] ?: 'assets/default.png') ?>" onerror="this.src='../assets/default.png'">
                        <div>
                            <div style="font-weight:600;"><?= htmlspecialchars($u['username']) ?></div>
                            <div style="color:#555;font-size:0.75rem;"><?= htmlspecialchars($u['email']) ?></div>
                        </div>
                    </div>
                </td>
                <td>
                    <?php
                    $rb = ['developer'=>'badge-dev','programmer'=>'badge-prog','backend_dev'=>'badge-back','frontend_dev'=>'badge-front','server_security'=>'badge-sec'];
                    $rc = $rb[$u['role']] ?? 'badge-dev';
                    ?>
                    <span class="badge <?=$rc?>"><?= str_replace('_',' ',ucfirst($u['role'])) ?></span>
                </td>
                <td>
                    <?php if ($u['is_verified']): ?><span class="badge badge-verified">✓ Verified</span><?php endif; ?>
                    <?php if (!empty($u['is_banned'])): ?><span class="badge badge-banned">🚫 Banned</span><?php endif; ?>
                    <?php if ($u['id'] == 1): ?><span class="badge" style="background:rgba(255,215,0,0.15);color:#ffd700;">👑 Admin</span><?php endif; ?>
                </td>
                <td style="color:#555;font-size:0.8rem;"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                <td>
                    <div style="display:flex;gap:5px;flex-wrap:wrap;">
                    <?php if ($u['id'] != 1): ?>
                        <!-- Change Role -->
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="change_role" value="1">
                            <input type="hidden" name="role_uid" value="<?=$u['id']?>">
                            <select name="new_role" onchange="this.form.submit()" style="background:#1a1a1a;border:1px solid #2a2a2a;color:#aaa;border-radius:6px;padding:3px 6px;font-size:0.75rem;">
                                <?php foreach (['developer','programmer','backend_dev','frontend_dev','server_security'] as $r): ?>
                                <option value="<?=$r?>" <?= $u['role']===$r?'selected':'' ?>><?= str_replace('_',' ',ucfirst($r)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                        <!-- Verify -->
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="verify_user" value="1">
                            <input type="hidden" name="verify_uid" value="<?=$u['id']?>">
                            <input type="hidden" name="verify_val" value="<?= $u['is_verified']?0:1 ?>">
                            <button class="btn btn-yellow btn-sm" title="<?= $u['is_verified']?'Cire Verification':'Tabbatar User' ?>">
                                <i class="fa fa-<?= $u['is_verified']?'times':'check' ?>"></i>
                            </button>
                        </form>
                        <!-- Ban -->
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="ban_user" value="1">
                            <input type="hidden" name="ban_uid" value="<?=$u['id']?>">
                            <input type="hidden" name="ban_val" value="<?= empty($u['is_banned'])?1:0 ?>">
                            <button class="btn btn-sm <?= empty($u['is_banned'])?'btn-grey':'btn-green' ?>" title="<?= empty($u['is_banned'])?'Hana User':'Sake Damar Shiga' ?>">
                                <i class="fa fa-<?= empty($u['is_banned'])?'ban':'unlock' ?>"></i>
                            </button>
                        </form>
                        <!-- Message -->
                        <button class="btn btn-grey btn-sm" onclick="quickMsg(<?=$u['id']?>, '<?= htmlspecialchars($u['username']) ?>')"><i class="fa fa-envelope"></i></button>
                        <!-- Delete -->
                        <form method="POST" style="display:inline" onsubmit="return confirm('Ka tabbata kana son share @<?= htmlspecialchars($u['username']) ?>?')">
                            <input type="hidden" name="delete_user" value="1">
                            <input type="hidden" name="del_id" value="<?=$u['id']?>">
                            <button class="btn btn-red btn-sm"><i class="fa fa-trash"></i></button>
                        </form>
                    <?php else: ?>
                        <span style="color:#555;font-size:0.78rem;">Admin Account</span>
                    <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- ══ BROADCAST ═════════════════════════════════════════════════ -->
    <div class="section" id="sec-broadcast">
        <div class="section-title"><h2><i class="fa fa-bullhorn"></i> Broadcast Saƙo</h2></div>
        <form method="POST" class="aform" style="max-width:560px;">
            <div>
                <div class="flbl">Target</div>
                <select name="target">
                    <option value="all">Duk Users</option>
                    <option value="developer">Developer</option>
                    <option value="programmer">Programmer</option>
                    <option value="backend_dev">Backend Dev</option>
                    <option value="frontend_dev">Frontend Dev</option>
                    <option value="server_security">Server Security</option>
                </select>
            </div>
            <div>
                <div class="flbl">Saƙo</div>
                <textarea name="broadcast_msg" rows="5" placeholder="Rubuta saƙon da za a aika..." required></textarea>
            </div>
            <button type="submit" name="send_broadcast" class="btn btn-cyan"><i class="fa fa-paper-plane"></i> Aika</button>
        </form>
    </div>

    <!-- ══ SITE SETTINGS ══════════════════════════════════════════════ -->
    <div class="section" id="sec-settings">
        <div class="section-title"><h2><i class="fa fa-gear"></i> Site Settings</h2></div>
        <form method="POST" class="aform" style="max-width:620px;">
            <div class="settings-row">
                <div>
                    <div class="flbl">WhatsApp Number</div>
                    <input type="text" name="admin_whatsapp" value="<?= htmlspecialchars($settings['admin_whatsapp'] ?? '') ?>" placeholder="+234...">
                </div>
                <div>
                    <div class="flbl">GitHub Username</div>
                    <input type="text" name="admin_github" value="<?= htmlspecialchars($settings['admin_github'] ?? '') ?>" placeholder="username">
                </div>
                <div>
                    <div class="flbl">Email</div>
                    <input type="email" name="admin_email" value="<?= htmlspecialchars($settings['admin_email'] ?? '') ?>" placeholder="admin@email.com">
                </div>
                <div>
                    <div class="flbl">Tech Skills (comma separated)</div>
                    <input type="text" name="admin_skills" value="<?= htmlspecialchars($settings['admin_skills'] ?? '') ?>" placeholder="PHP, MySQL, JavaScript...">
                </div>
            </div>
            <div>
                <div class="flbl">Bio / About Me (shown on index.php)</div>
                <textarea name="admin_bio" rows="4" placeholder="Bayani game da kai..."><?= htmlspecialchars($settings['admin_bio'] ?? '') ?></textarea>
            </div>
            <button type="submit" name="save_settings" class="btn btn-cyan"><i class="fa fa-save"></i> Adana Settings</button>
        </form>
    </div>
</div>

<!-- ══ ADD PROJECT MODAL ══════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-add-proj">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('modal-add-proj')">✕</button>
        <div class="modal-title"><i class="fa fa-plus"></i> Kara Sabon Project</div>
        <form method="POST" enctype="multipart/form-data" class="aform">
            <input type="hidden" name="add_project" value="1">
            <div class="form-row">
                <div>
                    <div class="flbl">Sunan Project *</div>
                    <input type="text" name="ptitle" required placeholder="Portfolio Website">
                </div>
                <div>
                    <div class="flbl">Category</div>
                    <select name="pcategory">
                        <option value="web">Web</option>
                        <option value="app">App</option>
                        <option value="ai">AI</option>
                        <option value="game">Game</option>
                        <option value="api">API</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
            <div>
                <div class="flbl">Bayani</div>
                <textarea name="pdesc" rows="3" placeholder="Bayani game da project..."></textarea>
            </div>
            <div class="form-row">
                <div>
                    <div class="flbl">Tech Stack</div>
                    <input type="text" name="ptech" placeholder="PHP, MySQL, JS...">
                </div>
                <div>
                    <div class="flbl">Project URL</div>
                    <input type="url" name="plink" placeholder="https://...">
                </div>
            </div>
            <div>
                <div class="flbl">Hoto</div>
                <input type="file" name="pimage" accept="image/*">
            </div>
            <label class="chk">
                <input type="checkbox" name="pfeatured"> ⭐ Featured (nuna a farko)
            </label>
            <button type="submit" class="btn btn-cyan"><i class="fa fa-save"></i> Adana Project</button>
        </form>
    </div>
</div>

<!-- ══ EDIT PROJECT MODAL ═════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-edit-proj">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('modal-edit-proj')">✕</button>
        <div class="modal-title"><i class="fa fa-edit"></i> Gyara Project</div>
        <form method="POST" enctype="multipart/form-data" class="aform" id="edit-proj-form">
            <input type="hidden" name="edit_project" value="1">
            <input type="hidden" name="pid" id="edit-pid">
            <div class="form-row">
                <div>
                    <div class="flbl">Sunan Project *</div>
                    <input type="text" name="ptitle" id="edit-ptitle" required>
                </div>
                <div>
                    <div class="flbl">Category</div>
                    <select name="pcategory" id="edit-pcategory">
                        <option value="web">Web</option>
                        <option value="app">App</option>
                        <option value="ai">AI</option>
                        <option value="game">Game</option>
                        <option value="api">API</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>
            <div>
                <div class="flbl">Bayani</div>
                <textarea name="pdesc" id="edit-pdesc" rows="3"></textarea>
            </div>
            <div class="form-row">
                <div>
                    <div class="flbl">Tech Stack</div>
                    <input type="text" name="ptech" id="edit-ptech">
                </div>
                <div>
                    <div class="flbl">Project URL</div>
                    <input type="url" name="plink" id="edit-plink">
                </div>
            </div>
            <div>
                <div class="flbl">Canja Hoto (zaɓi ba tilas)</div>
                <input type="file" name="pimage" accept="image/*">
            </div>
            <label class="chk">
                <input type="checkbox" name="pfeatured" id="edit-pfeatured"> ⭐ Featured
            </label>
            <button type="submit" class="btn btn-cyan"><i class="fa fa-save"></i> Adana Canje-canje</button>
        </form>
    </div>
</div>

<!-- ══ QUICK MESSAGE MODAL ════════════════════════════════════════════ -->
<div class="modal-overlay" id="modal-quickmsg">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModal('modal-quickmsg')">✕</button>
        <div class="modal-title"><i class="fa fa-envelope"></i> Aika Saƙo ga <span id="qmsg-uname"></span></div>
        <form method="POST" class="aform">
            <input type="hidden" name="send_broadcast" value="1">
            <input type="hidden" name="target" id="qmsg-target-field" value="all">
            <textarea name="broadcast_msg" rows="4" placeholder="Saƙonka..." required></textarea>
            <button type="submit" class="btn btn-cyan"><i class="fa fa-paper-plane"></i> Aika</button>
        </form>
    </div>
</div>

<script>
// ── SECTION NAV ───────────────────────────────────────────────────────
function showSection(name, link) {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById('sec-' + name).classList.add('active');
    document.querySelectorAll('.sidebar nav a').forEach(a => a.classList.remove('active'));
    if (link) link.classList.add('active');
    if (window.innerWidth <= 768) closeSidebar();
}

// ── SIDEBAR MOBILE ────────────────────────────────────────────────────
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
}

// ── MODALS ────────────────────────────────────────────────────────────
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-overlay').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

// ── EDIT PROJECT ──────────────────────────────────────────────────────
function editProject(p) {
    document.getElementById('edit-pid').value       = p.id;
    document.getElementById('edit-ptitle').value    = p.title;
    document.getElementById('edit-pdesc').value     = p.description;
    document.getElementById('edit-ptech').value     = p.tech_stack;
    document.getElementById('edit-plink').value     = p.project_url;
    document.getElementById('edit-pfeatured').checked = p.is_featured == 1;
    const sel = document.getElementById('edit-pcategory');
    if (sel) sel.value = p.category;
    openModal('modal-edit-proj');
}

// ── QUICK MSG ─────────────────────────────────────────────────────────
function quickMsg(uid, uname) {
    document.getElementById('qmsg-uname').textContent = '@' + uname;
    showSection('broadcast', null);
}

// ── SEARCH USERS ──────────────────────────────────────────────────────
function searchUsers() {
    const q = document.getElementById('user-search').value.toLowerCase();
    document.querySelectorAll('#users-tbody tr').forEach(row => {
        row.style.display = row.dataset.text.includes(q) ? '' : 'none';
    });
}

// ── SEARCH POSTS ──────────────────────────────────────────────────────
function searchPosts() {
    const q = document.getElementById('post-search').value.toLowerCase();
    const filter = document.querySelector('.section-tab.active')?.dataset.filter || 'all';
    document.querySelectorAll('.post-item').forEach(item => {
        const matchText = item.dataset.text.includes(q);
        const matchType = filter === 'all' || item.dataset.type === filter;
        item.style.display = matchText && matchType ? '' : 'none';
    });
}
function filterPosts(type, el) {
    document.querySelectorAll('.section-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    el.dataset.filter = type;
    const q = document.getElementById('post-search').value.toLowerCase();
    document.querySelectorAll('.post-item').forEach(item => {
        const matchText = item.dataset.text.includes(q);
        const matchType = type === 'all' || item.dataset.type === type;
        item.style.display = matchText && matchType ? '' : 'none';
    });
}

// ── CHART ─────────────────────────────────────────────────────────────
const chartLabels = <?= json_encode($chartLabels) ?>;
const chartVals   = <?= json_encode($chartVals) ?>;
const ctx = document.getElementById('signupChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: chartLabels.length ? chartLabels : ['No data'],
        datasets: [{
            label: 'Sabon Users',
            data: chartVals.length ? chartVals : [0],
            backgroundColor: 'rgba(0,212,255,0.3)',
            borderColor: '#00d4ff',
            borderWidth: 2,
            borderRadius: 6,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: '#1e1e1e' }, ticks: { color: '#555' }, beginAtZero: true },
            x: { grid: { color: '#1e1e1e' }, ticks: { color: '#555' } }
        }
    }
});
</script>
</body>
</html>
